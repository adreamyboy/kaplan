<?php
// created: 2021-10-18 09:14:16
$dictionary["admin_Orders"]["fields"]["admin_orders_aos_quotes"] = array (
  'name' => 'admin_orders_aos_quotes',
  'type' => 'link',
  'relationship' => 'admin_orders_aos_quotes',
  'source' => 'non-db',
  'module' => 'AOS_Quotes',
  'bean_name' => 'AOS_Quotes',
  'vname' => 'LBL_ADMIN_ORDERS_AOS_QUOTES_FROM_AOS_QUOTES_TITLE',
);
