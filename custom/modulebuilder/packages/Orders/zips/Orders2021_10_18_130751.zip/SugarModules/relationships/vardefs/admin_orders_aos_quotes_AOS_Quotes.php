<?php
// created: 2021-10-18 09:14:16
$dictionary["AOS_Quotes"]["fields"]["admin_orders_aos_quotes"] = array (
  'name' => 'admin_orders_aos_quotes',
  'type' => 'link',
  'relationship' => 'admin_orders_aos_quotes',
  'source' => 'non-db',
  'module' => 'admin_Orders',
  'bean_name' => false,
  'vname' => 'LBL_ADMIN_ORDERS_AOS_QUOTES_FROM_ADMIN_ORDERS_TITLE',
);
