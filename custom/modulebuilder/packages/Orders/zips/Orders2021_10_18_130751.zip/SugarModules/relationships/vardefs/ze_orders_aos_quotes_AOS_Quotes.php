<?php
// created: 2021-10-18 13:07:51
$dictionary["AOS_Quotes"]["fields"]["ze_orders_aos_quotes"] = array (
  'name' => 'ze_orders_aos_quotes',
  'type' => 'link',
  'relationship' => 'ze_orders_aos_quotes',
  'source' => 'non-db',
  'module' => 'ZE_Orders',
  'bean_name' => false,
  'vname' => 'LBL_ZE_ORDERS_AOS_QUOTES_FROM_ZE_ORDERS_TITLE',
);
