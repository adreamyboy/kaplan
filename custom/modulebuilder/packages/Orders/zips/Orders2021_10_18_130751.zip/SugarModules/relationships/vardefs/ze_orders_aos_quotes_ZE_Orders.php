<?php
// created: 2021-10-18 13:07:51
$dictionary["ZE_Orders"]["fields"]["ze_orders_aos_quotes"] = array (
  'name' => 'ze_orders_aos_quotes',
  'type' => 'link',
  'relationship' => 'ze_orders_aos_quotes',
  'source' => 'non-db',
  'module' => 'AOS_Quotes',
  'bean_name' => 'AOS_Quotes',
  'vname' => 'LBL_ZE_ORDERS_AOS_QUOTES_FROM_AOS_QUOTES_TITLE',
);
