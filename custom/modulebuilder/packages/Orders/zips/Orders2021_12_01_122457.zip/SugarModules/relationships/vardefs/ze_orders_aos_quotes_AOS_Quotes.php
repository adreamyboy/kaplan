<?php
// created: 2021-12-01 12:24:57
$dictionary["AOS_Quotes"]["fields"]["ze_orders_aos_quotes"] = array (
  'name' => 'ze_orders_aos_quotes',
  'type' => 'link',
  'relationship' => 'ze_orders_aos_quotes',
  'source' => 'non-db',
  'module' => 'ZE_Orders',
  'bean_name' => 'ZE_Orders',
  'vname' => 'LBL_ZE_ORDERS_AOS_QUOTES_FROM_ZE_ORDERS_TITLE',
);
