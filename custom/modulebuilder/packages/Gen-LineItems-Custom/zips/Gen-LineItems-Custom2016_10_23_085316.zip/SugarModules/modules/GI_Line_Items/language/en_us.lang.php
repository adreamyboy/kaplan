<?php 
 // created: 2016-10-23 08:53:15
$mod_strings['LNK_NEW_RECORD'] = 'Create Interests / Line Items';
$mod_strings['LNK_LIST'] = 'View Interests / Line Items';
$mod_strings['LNK_IMPORT_GI_LINE_ITEMS'] = 'Import Interests / Line Items';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Interest / Line Item List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Interest / Line Item';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Interest / Line Item';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Shipping Details (if applicable)';
$mod_strings['LBL_EXCLUDED_FROM_INVOICE'] = 'Excluded From Invoice';
$mod_strings['LBL_TOTAL_PRICE'] = 'Total Before Discount';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Assignee & History';
$mod_strings['LBL_DISCOUNT_TYPE'] = 'Discount Type';
$mod_strings['LBL_DISCOUNT_RATE'] = 'Discount Rate';
$mod_strings['LBL_DISCOUNT_RATIO'] = 'Discount Ratio';
$mod_strings['LBL_TOTAL_PRICE_NET'] = 'Total Price Net';
$mod_strings['LBL_TOTAL_DISCOUNT'] = 'Total Discount';
$mod_strings['LBL_QUANTITY'] = 'Quantity';
$mod_strings['LBL_REFERENCE'] = 'Reference';
$mod_strings['LBL_STATUS'] = 'Status';
$mod_strings['LBL_OPPORTUNITIES_GI_LINE_ITEMS_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_GI_PRODUCTS_GI_LINE_ITEMS_1_FROM_GI_PRODUCTS_TITLE'] = 'Products';
$mod_strings['LBL_NAME'] = 'Name';
$mod_strings['LBL_EXAM_RESULT'] = 'Exam Result';
$mod_strings['LBL_PROVISIONAL'] = 'Provisional';
$mod_strings['LBL_CREATE_FOLLOWUP_TASK'] = 'Create a New Follow-up Task';
$mod_strings['LBL_DATE_SYNC_WITH_MOODLE'] = 'Date Sync with Moodle';
$mod_strings['LBL_MOODLE_USER_ID'] = 'Moodle User ID';
$mod_strings['LBL_MOODLE_COHORT_ID'] = 'Moodle Cohort ID';
$mod_strings['LBL_DELIVERY_MODE'] = 'Preferred Delivery Mode';
$mod_strings['LBL_DATE_SHIPPED'] = 'Date Shipped';
$mod_strings['LBL_DATE_DELIVERED'] = 'Date Delivered';
$mod_strings['LBL_SHIPMENT_DETAILS'] = 'Shipment Details / Airway Bill No';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'Shipping Details (if applicable)';
$mod_strings['LBL_DESCRIPTION'] = 'Description';
$mod_strings['LBL_UNIT_PRICE'] = 'Unit Price';

?>
