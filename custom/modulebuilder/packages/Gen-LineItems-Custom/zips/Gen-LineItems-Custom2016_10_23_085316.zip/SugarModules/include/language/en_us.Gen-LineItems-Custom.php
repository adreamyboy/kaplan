<?php 
$app_list_strings['line_item_status_list'] = array (
  'Interested_Cold' => 'Interested Cold',
  'Interested_Warm' => 'Interested Warm',
  'Interested_Hot' => 'Interested Hot',
  'Not_Interested' => 'Not Interested',
  'Suspended' => 'Suspended / Inactive',
  'Active' => 'Active',
  'Complete' => 'Complete',
  'Cancelled' => 'Cancelled',
);$app_list_strings['discount_type_list'] = array (
  'Amount' => 'Amount',
  'Percentage' => 'Percentage',
);$app_list_strings['exam_result_list'] = array (
  '' => '',
  'Passed' => 'Passed',
  'Failed' => 'Failed',
  'Did_Not_Appear' => 'Did Not Appear',
  'Did_Not_Disclose' => 'Did Not Disclose',
);$app_list_strings['delivery_mode_list'] = array (
  '' => '',
  'Walk_In' => 'Walk-In',
  'In_Class' => 'In-Class',
  'By_Courier' => 'By-Courier',
  'Online' => 'Online',
);