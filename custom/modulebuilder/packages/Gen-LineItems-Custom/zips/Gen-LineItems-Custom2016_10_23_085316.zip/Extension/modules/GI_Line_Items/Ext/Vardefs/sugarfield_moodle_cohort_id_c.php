<?php
 // created: 2015-01-27 21:51:31
$dictionary['GI_Line_Items']['fields']['moodle_cohort_id_c']['labelValue']='Moodle Cohort ID';

 ?>