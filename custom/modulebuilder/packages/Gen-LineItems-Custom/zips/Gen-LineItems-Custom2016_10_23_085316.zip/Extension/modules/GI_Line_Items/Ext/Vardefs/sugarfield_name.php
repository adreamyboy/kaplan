<?php
 // created: 2014-06-11 17:20:03
$dictionary['GI_Line_Items']['fields']['name']['required']=false;
$dictionary['GI_Line_Items']['fields']['name']['importable']='false';
$dictionary['GI_Line_Items']['fields']['name']['duplicate_merge']='disabled';
$dictionary['GI_Line_Items']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['GI_Line_Items']['fields']['name']['merge_filter']='disabled';
$dictionary['GI_Line_Items']['fields']['name']['unified_search']=false;

 ?>