<?php
 // created: 2014-05-29 05:04:24
$dictionary['GI_Line_Items']['fields']['quantity']['default']='1';

 ?>