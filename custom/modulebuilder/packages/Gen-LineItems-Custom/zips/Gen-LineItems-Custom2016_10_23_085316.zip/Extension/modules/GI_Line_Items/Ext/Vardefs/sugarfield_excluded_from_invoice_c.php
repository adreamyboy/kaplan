<?php
 // created: 2014-05-08 10:01:06
$dictionary['GI_Line_Items']['fields']['excluded_from_invoice_c']['labelValue']='Excluded From Invoice';

 ?>