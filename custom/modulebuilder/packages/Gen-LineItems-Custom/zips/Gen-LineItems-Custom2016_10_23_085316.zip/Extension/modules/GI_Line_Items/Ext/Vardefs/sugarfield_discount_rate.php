<?php
 // created: 2016-05-02 23:25:04
$dictionary['GI_Line_Items']['fields']['discount_rate']['required']=false;
$dictionary['GI_Line_Items']['fields']['discount_rate']['audited']=true;

 ?>