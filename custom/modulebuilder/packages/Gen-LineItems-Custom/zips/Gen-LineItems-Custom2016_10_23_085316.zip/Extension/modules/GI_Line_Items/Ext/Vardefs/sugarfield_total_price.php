<?php
 // created: 2014-05-29 04:30:59
$dictionary['GI_Line_Items']['fields']['total_price']['required']=false;

 ?>