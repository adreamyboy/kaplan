<?php
 // created: 2014-08-13 02:35:07
$dictionary['GI_Line_Items']['fields']['discount_type_c']['labelValue']='Discount Type';

 ?>