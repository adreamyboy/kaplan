<?php
 // created: 2015-09-13 06:32:05
$dictionary['GI_Line_Items']['fields']['shipment_details_c']['labelValue']='Shipment Details / Airway Bill No';

 ?>