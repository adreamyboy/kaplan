<?php
 // created: 2015-07-29 02:47:46
$dictionary['GI_Line_Items']['fields']['exam_result_c']['labelValue']='Exam Result';

 ?>