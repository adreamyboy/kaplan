<?php
 // created: 2014-09-28 06:56:44
$dictionary['GI_Line_Items']['fields']['provisional_c']['labelValue']='Provisional';
$dictionary['GI_Line_Items']['fields']['provisional_c']['massupdate']=true;

 ?>