<?php
 // created: 2014-05-29 04:30:43
$dictionary['GI_Line_Items']['fields']['total_discount']['required']=false;

 ?>