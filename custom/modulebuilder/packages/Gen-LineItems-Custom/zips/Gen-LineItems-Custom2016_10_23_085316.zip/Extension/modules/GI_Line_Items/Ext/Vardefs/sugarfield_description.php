<?php
 // created: 2015-09-13 06:31:43
$dictionary['GI_Line_Items']['fields']['description']['comments']='Full text of the note';
$dictionary['GI_Line_Items']['fields']['description']['merge_filter']='disabled';
$dictionary['GI_Line_Items']['fields']['description']['cols']='50';

 ?>