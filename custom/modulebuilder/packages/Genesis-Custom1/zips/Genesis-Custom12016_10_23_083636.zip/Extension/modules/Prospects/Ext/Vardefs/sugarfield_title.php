<?php
 // created: 2014-06-18 14:03:40
$dictionary['Prospect']['fields']['title']['comments']='The title of the contact';
$dictionary['Prospect']['fields']['title']['merge_filter']='disabled';

 ?>