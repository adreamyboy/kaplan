<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_eLearning_Courses']['subpanel_setup']['gi_products_gi_elearning_courses_1']['override_subpanel_name'] = 'GI_eLearning_Courses_subpanel_gi_products_gi_elearning_courses_1';
?>