<?php
 // created: 2015-07-01 02:51:34
$dictionary['GI_Target_Allocations']['fields']['name']['required']=false;
$dictionary['GI_Target_Allocations']['fields']['name']['audited']=true;
$dictionary['GI_Target_Allocations']['fields']['name']['duplicate_merge']='disabled';
$dictionary['GI_Target_Allocations']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['GI_Target_Allocations']['fields']['name']['merge_filter']='disabled';
$dictionary['GI_Target_Allocations']['fields']['name']['unified_search']=false;

 ?>