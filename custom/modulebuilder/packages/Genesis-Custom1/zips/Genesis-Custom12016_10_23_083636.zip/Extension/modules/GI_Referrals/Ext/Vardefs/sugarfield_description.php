<?php
 // created: 2016-02-02 11:38:02
$dictionary['GI_Referrals']['fields']['description']['audited']=true;
$dictionary['GI_Referrals']['fields']['description']['comments']='Full text of the note';
$dictionary['GI_Referrals']['fields']['description']['merge_filter']='disabled';

 ?>