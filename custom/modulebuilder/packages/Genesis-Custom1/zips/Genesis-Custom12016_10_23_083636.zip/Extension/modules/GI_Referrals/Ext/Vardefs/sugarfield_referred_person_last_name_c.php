<?php
 // created: 2016-02-02 11:36:08
$dictionary['GI_Referrals']['fields']['referred_person_last_name_c']['labelValue']='Referred Person Last Name';

 ?>