<?php
 // created: 2015-05-17 08:00:31
$layout_defs["GI_Forecastings"]["subpanel_setup"]['gi_forecastings_gi_commission_splits_1'] = array (
  'order' => 400,
  'module' => 'GI_Commission_Splits',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_FORECASTINGS_GI_COMMISSION_SPLITS_1_FROM_GI_COMMISSION_SPLITS_TITLE',
  'get_subpanel_data' => 'gi_forecastings_gi_commission_splits_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
