<?php
 // created: 2015-05-17 07:55:09
$dictionary['GI_Forecastings']['fields']['q3_c']['labelValue']='Q3';

 ?>