<?php
 // created: 2015-07-01 01:17:11
$dictionary['GI_Target_Allocations']['fields']['q1_amount_c']['labelValue']='Q1 Amount';

 ?>