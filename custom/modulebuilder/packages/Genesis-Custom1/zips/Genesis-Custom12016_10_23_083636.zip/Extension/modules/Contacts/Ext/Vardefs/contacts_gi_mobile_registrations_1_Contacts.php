<?php
// created: 2015-10-22 07:35:50
$dictionary["Contact"]["fields"]["contacts_gi_mobile_registrations_1"] = array (
  'name' => 'contacts_gi_mobile_registrations_1',
  'type' => 'link',
  'relationship' => 'contacts_gi_mobile_registrations_1',
  'source' => 'non-db',
  'module' => 'GI_Mobile_Registrations',
  'bean_name' => 'GI_Mobile_Registrations',
  'side' => 'right',
  'vname' => 'LBL_CONTACTS_GI_MOBILE_REGISTRATIONS_1_FROM_GI_MOBILE_REGISTRATIONS_TITLE',
);
