<?php
 // created: 2014-11-11 02:57:31
$dictionary['GI_Discounts']['fields']['valid_from_days_c']['options']='numeric_range_search_dom';
$dictionary['GI_Discounts']['fields']['valid_from_days_c']['labelValue']='Valid From (Days)';
$dictionary['GI_Discounts']['fields']['valid_from_days_c']['enable_range_search']='1';

 ?>