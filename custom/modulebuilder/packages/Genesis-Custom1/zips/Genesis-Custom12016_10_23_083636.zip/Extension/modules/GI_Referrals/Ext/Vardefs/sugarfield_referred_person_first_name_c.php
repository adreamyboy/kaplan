<?php
 // created: 2016-02-02 11:36:21
$dictionary['GI_Referrals']['fields']['referred_person_first_name_c']['labelValue']='Referred Person First Name';

 ?>