<?php
 // created: 2014-05-29 08:26:25
$dictionary['GI_Credit_Notes']['fields']['amount_c']['labelValue']='Amount';

 ?>