<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Line_Items_Change_Requests']['subpanel_setup']['gi_line_items_change_requests_gi_products_1']['override_subpanel_name'] = 'GI_Line_Items_Change_Requests_subpanel_gi_line_items_change_requests_gi_products_1';
?>