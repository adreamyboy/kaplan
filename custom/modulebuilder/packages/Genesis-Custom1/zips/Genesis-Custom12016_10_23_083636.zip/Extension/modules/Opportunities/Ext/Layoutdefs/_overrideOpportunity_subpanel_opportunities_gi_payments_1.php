<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['opportunities_gi_payments_1']['override_subpanel_name'] = 'Opportunity_subpanel_opportunities_gi_payments_1';
?>