<?php
 // created: 2015-03-10 21:07:34
$dictionary['GI_Line_Items_Change_Requests']['fields']['limit_to_capacity_c']['labelValue']='Limit to Capacity / Approve Automatically';

 ?>