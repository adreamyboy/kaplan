<?php
 // created: 2015-07-01 01:33:33
$dictionary['GI_Target_Allocations']['fields']['q2_percentage_c']['labelValue']='Q2 %';

 ?>