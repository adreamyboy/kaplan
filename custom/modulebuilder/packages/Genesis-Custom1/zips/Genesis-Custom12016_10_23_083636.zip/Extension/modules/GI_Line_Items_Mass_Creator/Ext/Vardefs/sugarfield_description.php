<?php
 // created: 2015-11-11 09:18:27
$dictionary['GI_Line_Items_Mass_Creator']['fields']['description']['comments']='Full text of the note';
$dictionary['GI_Line_Items_Mass_Creator']['fields']['description']['merge_filter']='disabled';
$dictionary['GI_Line_Items_Mass_Creator']['fields']['description']['required']=true;
$dictionary['GI_Line_Items_Mass_Creator']['fields']['description']['audited']=true;

 ?>