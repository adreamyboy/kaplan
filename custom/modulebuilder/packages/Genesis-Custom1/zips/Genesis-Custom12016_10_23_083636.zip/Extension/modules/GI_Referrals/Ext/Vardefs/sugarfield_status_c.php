<?php
 // created: 2016-02-02 11:45:19
$dictionary['GI_Referrals']['fields']['status_c']['labelValue']='Status';

 ?>