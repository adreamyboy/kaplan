<?php
 // created: 2015-11-25 06:10:33
$dictionary['GI_Line_Items_Mass_Creator']['fields']['unit_price_zero_c']['labelValue']='Unit Price Zero?';

 ?>