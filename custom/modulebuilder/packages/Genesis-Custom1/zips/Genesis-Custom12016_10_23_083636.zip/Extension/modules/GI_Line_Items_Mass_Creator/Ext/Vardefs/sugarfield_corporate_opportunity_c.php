<?php
 // created: 2015-11-25 06:29:29
$dictionary['GI_Line_Items_Mass_Creator']['fields']['corporate_opportunity_c']['labelValue']='Corporate Opportunity';

 ?>