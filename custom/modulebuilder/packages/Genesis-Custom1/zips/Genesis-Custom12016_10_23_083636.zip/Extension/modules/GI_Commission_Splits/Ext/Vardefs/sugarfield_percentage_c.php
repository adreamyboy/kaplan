<?php
 // created: 2015-05-17 08:41:29
$dictionary['GI_Commission_Splits']['fields']['percentage_c']['labelValue']='Percentage';

 ?>