<?php
 // created: 2014-06-26 14:54:21
$dictionary['GI_Payments']['fields']['request_change_c']['labelValue']='Request Change';

 ?>