<?php
 // created: 2015-01-27 22:18:47
$dictionary['Contact']['fields']['primary_address_state']['audited']=true;
$dictionary['Contact']['fields']['primary_address_state']['comments']='State for primary address';
$dictionary['Contact']['fields']['primary_address_state']['merge_filter']='disabled';

 ?>