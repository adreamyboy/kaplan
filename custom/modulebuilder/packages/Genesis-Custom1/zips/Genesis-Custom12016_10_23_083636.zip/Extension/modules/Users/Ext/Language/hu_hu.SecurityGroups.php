<?php
global $mod_strings;

$mod_strings = array_merge($mod_strings,
	array(
	'LBL_LIST_NONINHERITABLE' => "Nem Örökölhető",
	'LBL_PRIMARY_GROUP' => "Elsődleges csoport",
	)
);
?>
