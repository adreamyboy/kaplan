<?php
// created: 2014-11-11 03:01:02
$dictionary["GI_Discounts"]["fields"]["gi_discounts_prospectlists_1"] = array (
  'name' => 'gi_discounts_prospectlists_1',
  'type' => 'link',
  'relationship' => 'gi_discounts_prospectlists_1',
  'source' => 'non-db',
  'module' => 'ProspectLists',
  'bean_name' => 'ProspectList',
  'vname' => 'LBL_GI_DISCOUNTS_PROSPECTLISTS_1_FROM_PROSPECTLISTS_TITLE',
);
