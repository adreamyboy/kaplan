<?php
// created: 2014-11-20 05:53:08
$dictionary["User"]["fields"]["gi_products_catalog_users_1"] = array (
  'name' => 'gi_products_catalog_users_1',
  'type' => 'link',
  'relationship' => 'gi_products_catalog_users_1',
  'source' => 'non-db',
  'module' => 'GI_Products_Catalog',
  'bean_name' => 'GI_Products_Catalog',
  'vname' => 'LBL_GI_PRODUCTS_CATALOG_USERS_1_FROM_GI_PRODUCTS_CATALOG_TITLE',
);
