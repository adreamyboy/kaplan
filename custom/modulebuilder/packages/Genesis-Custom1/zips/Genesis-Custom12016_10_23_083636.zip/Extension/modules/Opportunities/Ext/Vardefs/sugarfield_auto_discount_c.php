<?php
 // created: 2015-01-22 01:45:09
$dictionary['Opportunity']['fields']['auto_discount_c']['labelValue']='Auto Discount?';
$dictionary['Opportunity']['fields']['auto_discount_c']['massupdate']=true;

 ?>