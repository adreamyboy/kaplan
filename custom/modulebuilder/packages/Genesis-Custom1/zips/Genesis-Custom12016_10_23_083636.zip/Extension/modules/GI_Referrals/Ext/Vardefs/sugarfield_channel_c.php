<?php
 // created: 2016-02-02 11:50:44
$dictionary['GI_Referrals']['fields']['channel_c']['labelValue']='Channel';

 ?>