<?php
 // created: 2014-05-29 07:52:17
$dictionary['Opportunity']['fields']['total_creditnote_allocations_c']['labelValue']='Total Credit Note Allocations';

 ?>