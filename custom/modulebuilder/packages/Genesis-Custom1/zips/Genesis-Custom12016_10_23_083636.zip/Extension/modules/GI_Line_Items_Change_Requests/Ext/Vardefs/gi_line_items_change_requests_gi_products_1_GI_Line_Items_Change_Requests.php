<?php
// created: 2015-03-10 20:38:00
$dictionary["GI_Line_Items_Change_Requests"]["fields"]["gi_line_items_change_requests_gi_products_1"] = array (
  'name' => 'gi_line_items_change_requests_gi_products_1',
  'type' => 'link',
  'relationship' => 'gi_line_items_change_requests_gi_products_1',
  'source' => 'non-db',
  'module' => 'GI_Products',
  'bean_name' => 'GI_Products',
  'side' => 'right',
  'vname' => 'LBL_GI_LINE_ITEMS_CHANGE_REQUESTS_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
);
