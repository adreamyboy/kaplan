<?php
 // created: 2015-05-17 07:54:53
$dictionary['GI_Forecastings']['fields']['q2_c']['labelValue']='Q2';

 ?>