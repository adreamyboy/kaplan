<?php
// created: 2015-11-11 09:13:31
$dictionary["GI_Line_Items_Mass_Creator"]["fields"]["gi_line_items_mass_creator_notes_1"] = array (
  'name' => 'gi_line_items_mass_creator_notes_1',
  'type' => 'link',
  'relationship' => 'gi_line_items_mass_creator_notes_1',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_GI_LINE_ITEMS_MASS_CREATOR_NOTES_1_FROM_NOTES_TITLE',
);
