<?php
 // created: 2014-06-18 01:20:18
$dictionary['Opportunity']['fields']['customer_lpo_c']['labelValue']='Customer LPO';

 ?>