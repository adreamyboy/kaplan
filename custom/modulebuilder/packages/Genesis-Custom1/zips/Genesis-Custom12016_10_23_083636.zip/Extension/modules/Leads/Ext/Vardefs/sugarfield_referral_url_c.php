<?php
 // created: 2014-08-06 21:06:37
$dictionary['Lead']['fields']['referral_url_c']['labelValue']='Referral URL';

 ?>