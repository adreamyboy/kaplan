<?php
 // created: 2014-10-12 04:21:20
$layout_defs["ProspectLists"]["subpanel_setup"]['gi_sms_messages_prospectlists_1'] = array (
  'order' => 100,
  'module' => 'GI_SMS_Messages',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_SMS_MESSAGES_PROSPECTLISTS_1_FROM_GI_SMS_MESSAGES_TITLE',
  'get_subpanel_data' => 'gi_sms_messages_prospectlists_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
