<?php
// created: 2015-05-17 08:00:31
$dictionary["GI_Forecastings"]["fields"]["gi_forecastings_gi_commission_splits_1"] = array (
  'name' => 'gi_forecastings_gi_commission_splits_1',
  'type' => 'link',
  'relationship' => 'gi_forecastings_gi_commission_splits_1',
  'source' => 'non-db',
  'module' => 'GI_Commission_Splits',
  'bean_name' => 'GI_Commission_Splits',
  'side' => 'right',
  'vname' => 'LBL_GI_FORECASTINGS_GI_COMMISSION_SPLITS_1_FROM_GI_COMMISSION_SPLITS_TITLE',
);
