<?php
 // created: 2015-10-29 07:47:11
$dictionary['Opportunity']['fields']['no_of_not_held_activities_c']['options']='numeric_range_search_dom';
$dictionary['Opportunity']['fields']['no_of_not_held_activities_c']['labelValue']='No. of Not-Held Activities';
$dictionary['Opportunity']['fields']['no_of_not_held_activities_c']['enable_range_search']='1';

 ?>