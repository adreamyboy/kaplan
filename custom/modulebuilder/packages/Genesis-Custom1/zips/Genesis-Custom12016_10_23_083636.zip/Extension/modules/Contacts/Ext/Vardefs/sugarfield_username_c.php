<?php
 // created: 2014-12-27 10:42:17
$dictionary['Contact']['fields']['username_c']['labelValue']='Username';

 ?>