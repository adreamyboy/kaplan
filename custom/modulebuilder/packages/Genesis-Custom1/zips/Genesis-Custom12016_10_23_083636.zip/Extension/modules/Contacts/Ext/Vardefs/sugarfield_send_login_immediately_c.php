<?php
 // created: 2014-12-09 11:00:19
$dictionary['Contact']['fields']['send_login_immediately_c']['labelValue']='Send Login Immediately?';
$dictionary['Contact']['fields']['send_login_immediately_c']['massupdate']=true;

 ?>