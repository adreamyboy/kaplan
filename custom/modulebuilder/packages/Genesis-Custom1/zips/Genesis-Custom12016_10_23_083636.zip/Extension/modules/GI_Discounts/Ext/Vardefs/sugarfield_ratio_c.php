<?php
 // created: 2014-11-11 02:55:08
$dictionary['GI_Discounts']['fields']['ratio_c']['labelValue']='Ratio';

 ?>