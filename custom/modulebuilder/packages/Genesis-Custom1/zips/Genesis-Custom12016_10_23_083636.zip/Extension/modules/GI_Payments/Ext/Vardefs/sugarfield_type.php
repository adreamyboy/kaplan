<?php
 // created: 2014-08-31 22:32:23
$dictionary['GI_Payments']['fields']['type']['audited']=true;
$dictionary['GI_Payments']['fields']['type']['default']='Receipt';

 ?>