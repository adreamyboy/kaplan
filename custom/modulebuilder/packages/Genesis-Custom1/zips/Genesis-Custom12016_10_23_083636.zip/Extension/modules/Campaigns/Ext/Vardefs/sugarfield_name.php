<?php
 // created: 2014-10-13 04:53:20
$dictionary['Campaign']['fields']['name']['len']='70';
$dictionary['Campaign']['fields']['name']['comments']='The name of the campaign';
$dictionary['Campaign']['fields']['name']['merge_filter']='disabled';
$dictionary['Campaign']['fields']['name']['unified_search']=false;
$dictionary['Campaign']['fields']['name']['full_text_search']=array (
);

 ?>