<?php
 // created: 2016-02-02 11:35:15
$dictionary['GI_Referrals']['fields']['referring_person_last_name_c']['labelValue']='Referring Person Last Name';

 ?>