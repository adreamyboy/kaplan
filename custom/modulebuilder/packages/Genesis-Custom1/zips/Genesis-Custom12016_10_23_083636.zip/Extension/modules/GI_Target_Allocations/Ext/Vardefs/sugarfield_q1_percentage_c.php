<?php
 // created: 2015-07-01 01:29:28
$dictionary['GI_Target_Allocations']['fields']['q1_percentage_c']['labelValue']='Q1 %';

 ?>