<?php
// created: 2015-05-17 07:58:54
$dictionary["GI_Forecastings"]["fields"]["gi_forecastings_gi_products_1"] = array (
  'name' => 'gi_forecastings_gi_products_1',
  'type' => 'link',
  'relationship' => 'gi_forecastings_gi_products_1',
  'source' => 'non-db',
  'module' => 'GI_Products',
  'bean_name' => 'GI_Products',
  'side' => 'right',
  'vname' => 'LBL_GI_FORECASTINGS_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
);
