<?php
 // created: 2015-02-19 01:08:43
$dictionary['Contact']['fields']['awarded_certifications_c']['labelValue']='Awarded Certifications';

 ?>