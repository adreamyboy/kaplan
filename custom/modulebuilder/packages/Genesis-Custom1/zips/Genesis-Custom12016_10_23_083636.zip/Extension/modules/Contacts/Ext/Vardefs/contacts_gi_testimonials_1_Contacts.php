<?php
// created: 2015-02-16 21:48:56
$dictionary["Contact"]["fields"]["contacts_gi_testimonials_1"] = array (
  'name' => 'contacts_gi_testimonials_1',
  'type' => 'link',
  'relationship' => 'contacts_gi_testimonials_1',
  'source' => 'non-db',
  'module' => 'GI_Testimonials',
  'bean_name' => 'GI_Testimonials',
  'side' => 'right',
  'vname' => 'LBL_CONTACTS_GI_TESTIMONIALS_1_FROM_GI_TESTIMONIALS_TITLE',
);
