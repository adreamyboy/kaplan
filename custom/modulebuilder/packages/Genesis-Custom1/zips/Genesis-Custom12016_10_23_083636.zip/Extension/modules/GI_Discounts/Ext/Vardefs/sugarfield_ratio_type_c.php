<?php
 // created: 2014-11-11 02:56:16
$dictionary['GI_Discounts']['fields']['ratio_type_c']['labelValue']='Ratio Type';

 ?>