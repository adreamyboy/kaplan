<?php
 // created: 2015-02-16 21:48:56
$layout_defs["Contacts"]["subpanel_setup"]['contacts_gi_testimonials_1'] = array (
  'order' => 100,
  'module' => 'GI_Testimonials',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CONTACTS_GI_TESTIMONIALS_1_FROM_GI_TESTIMONIALS_TITLE',
  'get_subpanel_data' => 'contacts_gi_testimonials_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
