<?php
//auto-generated file DO NOT EDIT
$layout_defs['ProspectLists']['subpanel_setup']['contacts']['override_subpanel_name'] = 'ProspectList_subpanel_contacts';
?>