<?php
 // created: 2016-06-09 08:20:42
$dictionary['Contact']['fields']['university_c']['labelValue']='University';

 ?>