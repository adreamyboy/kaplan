<?php
 // created: 2015-10-25 04:24:25
$dictionary['Opportunity']['fields']['last_activity_date_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['last_activity_date_c']['labelValue']='Last Activity Date';
$dictionary['Opportunity']['fields']['last_activity_date_c']['enable_range_search']='1';

 ?>