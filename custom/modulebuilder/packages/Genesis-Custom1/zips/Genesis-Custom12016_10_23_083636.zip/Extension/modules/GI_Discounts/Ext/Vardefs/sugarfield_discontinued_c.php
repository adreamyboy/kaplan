<?php
 // created: 2014-11-11 02:50:21
$dictionary['GI_Discounts']['fields']['discontinued_c']['labelValue']='Discontinued';

 ?>