<?php
 // created: 2015-04-12 22:46:03
$dictionary['GI_Payments']['fields']['send_payment_via_email_c']['labelValue']='Send Payment via Email';

 ?>