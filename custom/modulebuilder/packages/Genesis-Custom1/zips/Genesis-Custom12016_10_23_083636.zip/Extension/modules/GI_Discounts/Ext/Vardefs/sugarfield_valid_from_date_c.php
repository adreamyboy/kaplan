<?php
 // created: 2014-11-11 02:58:26
$dictionary['GI_Discounts']['fields']['valid_from_date_c']['options']='date_range_search_dom';
$dictionary['GI_Discounts']['fields']['valid_from_date_c']['labelValue']='Valid From (Date)';
$dictionary['GI_Discounts']['fields']['valid_from_date_c']['enable_range_search']='1';

 ?>