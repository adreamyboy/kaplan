<?php
 // created: 2014-08-16 16:04:10
$dictionary['GI_Payments']['fields']['date_cleared']['audited']=true;
$dictionary['GI_Payments']['fields']['date_cleared']['display_default']='';
$dictionary['GI_Payments']['fields']['date_cleared']['options']='date_range_search_dom';
$dictionary['GI_Payments']['fields']['date_cleared']['enable_range_search']='1';

 ?>