<?php
 // created: 2014-05-08 16:28:15
$dictionary['Opportunity']['fields']['quickbooks_invoice_c']['labelValue']='QuickBooks Invoice';

 ?>