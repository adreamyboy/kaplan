<?php
// created: 2015-11-11 03:49:00
$dictionary["ProspectList"]["fields"]["gi_line_items_mass_creator_prospectlists_1"] = array (
  'name' => 'gi_line_items_mass_creator_prospectlists_1',
  'type' => 'link',
  'relationship' => 'gi_line_items_mass_creator_prospectlists_1',
  'source' => 'non-db',
  'module' => 'GI_Line_Items_Mass_Creator',
  'bean_name' => 'GI_Line_Items_Mass_Creator',
  'vname' => 'LBL_GI_LINE_ITEMS_MASS_CREATOR_PROSPECTLISTS_1_FROM_GI_LINE_ITEMS_MASS_CREATOR_TITLE',
);
