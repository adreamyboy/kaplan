<?php
 // created: 2014-06-26 22:37:58
$dictionary['GI_Payments']['fields']['quickbooks_payment_c']['labelValue']='QuickBooks Payment';

 ?>