<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Discounts']['subpanel_setup']['gi_discounts_gi_line_items_1']['override_subpanel_name'] = 'GI_Discounts_subpanel_gi_discounts_gi_line_items_1';
?>