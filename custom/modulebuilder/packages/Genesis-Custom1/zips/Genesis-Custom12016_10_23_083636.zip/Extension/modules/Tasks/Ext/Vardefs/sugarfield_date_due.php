<?php
 // created: 2015-10-29 06:55:32
$dictionary['Task']['fields']['date_due']['required']=true;
$dictionary['Task']['fields']['date_due']['audited']=true;
$dictionary['Task']['fields']['date_due']['merge_filter']='disabled';

 ?>