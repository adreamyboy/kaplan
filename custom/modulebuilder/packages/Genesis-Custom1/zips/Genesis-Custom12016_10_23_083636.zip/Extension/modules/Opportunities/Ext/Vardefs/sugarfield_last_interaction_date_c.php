<?php
 // created: 2016-01-23 19:37:44
$dictionary['Opportunity']['fields']['last_interaction_date_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['last_interaction_date_c']['labelValue']='Last Interaction Date';
$dictionary['Opportunity']['fields']['last_interaction_date_c']['enable_range_search']='1';

 ?>