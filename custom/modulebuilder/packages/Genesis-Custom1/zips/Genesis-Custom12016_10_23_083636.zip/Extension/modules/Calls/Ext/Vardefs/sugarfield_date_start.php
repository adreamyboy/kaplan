<?php
 // created: 2015-10-29 06:56:37
$dictionary['Call']['fields']['date_start']['audited']=true;
$dictionary['Call']['fields']['date_start']['comments']='Date in which call is schedule to (or did) start';
$dictionary['Call']['fields']['date_start']['merge_filter']='disabled';

 ?>