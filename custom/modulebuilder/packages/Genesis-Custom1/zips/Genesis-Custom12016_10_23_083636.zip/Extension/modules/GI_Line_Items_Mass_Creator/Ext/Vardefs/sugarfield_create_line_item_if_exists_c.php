<?php
 // created: 2015-11-11 11:32:39
$dictionary['GI_Line_Items_Mass_Creator']['fields']['create_line_item_if_exists_c']['labelValue']='Create line item even if it exists?';

 ?>