<?php
 // created: 2016-02-02 11:51:20
$dictionary['GI_Referrals']['fields']['name']['required']=false;
$dictionary['GI_Referrals']['fields']['name']['duplicate_merge']='disabled';
$dictionary['GI_Referrals']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['GI_Referrals']['fields']['name']['merge_filter']='disabled';
$dictionary['GI_Referrals']['fields']['name']['unified_search']=false;

 ?>