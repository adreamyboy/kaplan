<?php
 // created: 2015-08-19 23:05:12
$dictionary['GI_eLearning_Courses']['fields']['moodle_course_id_c']['labelValue']='Moodle Course ID';

 ?>