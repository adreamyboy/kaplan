<?php
// created: 2014-05-06 12:41:33
$dictionary["Contact"]["fields"]["contacts_gi_line_items_1"] = array (
  'name' => 'contacts_gi_line_items_1',
  'type' => 'link',
  'relationship' => 'contacts_gi_line_items_1',
  'source' => 'non-db',
  'module' => 'GI_Line_Items',
  'bean_name' => 'GI_Line_Items',
  'side' => 'right',
  'vname' => 'LBL_CONTACTS_GI_LINE_ITEMS_1_FROM_GI_LINE_ITEMS_TITLE',
);
