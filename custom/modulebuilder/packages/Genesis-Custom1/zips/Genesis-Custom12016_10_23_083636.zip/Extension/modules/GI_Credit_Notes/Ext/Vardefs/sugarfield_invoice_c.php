<?php
 // created: 2015-02-28 03:57:27
$dictionary['GI_Credit_Notes']['fields']['invoice_c']['labelValue']='Invoice';

 ?>