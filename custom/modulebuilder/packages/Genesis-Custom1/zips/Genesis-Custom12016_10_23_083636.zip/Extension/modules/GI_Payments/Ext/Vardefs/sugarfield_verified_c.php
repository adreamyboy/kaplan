<?php
 // created: 2014-06-28 11:17:15
$dictionary['GI_Payments']['fields']['verified_c']['labelValue']='Verified';

 ?>