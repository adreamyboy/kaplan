<?php
 // created: 2015-10-22 07:26:01
$dictionary['GI_Mobile_Registrations']['fields']['description']['required']=true;
$dictionary['GI_Mobile_Registrations']['fields']['description']['audited']=true;
$dictionary['GI_Mobile_Registrations']['fields']['description']['comments']='Full text of the note';
$dictionary['GI_Mobile_Registrations']['fields']['description']['merge_filter']='disabled';

 ?>