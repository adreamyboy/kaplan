<?php
 // created: 2015-05-17 07:55:48
$dictionary['GI_Forecastings']['fields']['discontinued_c']['labelValue']='Discontinued';

 ?>