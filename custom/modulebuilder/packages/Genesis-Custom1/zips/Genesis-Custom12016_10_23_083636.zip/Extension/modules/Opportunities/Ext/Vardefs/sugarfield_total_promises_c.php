<?php
 // created: 2014-12-15 10:15:06
$dictionary['Opportunity']['fields']['total_promises_c']['labelValue']='Total Promises';

 ?>