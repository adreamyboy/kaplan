<?php
 // created: 2016-02-02 11:34:52
$dictionary['GI_Referrals']['fields']['referring_person_mobile_c']['labelValue']='Referring Person Mobile';

 ?>