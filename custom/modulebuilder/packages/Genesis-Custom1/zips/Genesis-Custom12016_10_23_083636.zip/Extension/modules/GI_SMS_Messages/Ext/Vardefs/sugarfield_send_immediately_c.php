<?php
 // created: 2014-10-12 04:17:31
$dictionary['GI_SMS_Messages']['fields']['send_immediately_c']['labelValue']='Send Immediately';

 ?>