<?php
 // created: 2015-11-11 09:25:41
$dictionary['GI_Line_Items_Mass_Creator']['fields']['discount_ratio_c']['labelValue']='Discount Ratio';

 ?>