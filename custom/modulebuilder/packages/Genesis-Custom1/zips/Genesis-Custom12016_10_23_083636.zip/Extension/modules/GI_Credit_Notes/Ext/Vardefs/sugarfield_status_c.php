<?php
 // created: 2014-06-03 03:22:25
$dictionary['GI_Credit_Notes']['fields']['status_c']['labelValue']='Status';

 ?>