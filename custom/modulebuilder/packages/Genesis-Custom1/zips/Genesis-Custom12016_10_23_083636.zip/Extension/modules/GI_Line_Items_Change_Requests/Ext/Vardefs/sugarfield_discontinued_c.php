<?php
 // created: 2015-03-10 21:05:34
$dictionary['GI_Line_Items_Change_Requests']['fields']['discontinued_c']['labelValue']='Discontinued';

 ?>