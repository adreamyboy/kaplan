<?php

$mod_strings = array_merge($mod_strings,
    array(
         'LBL_LIST_NONINHERITABLE' => "Não Herdável",
         'LBL_PRIMARY_GROUP' => "Grupo Principal",
    )
);
?>
