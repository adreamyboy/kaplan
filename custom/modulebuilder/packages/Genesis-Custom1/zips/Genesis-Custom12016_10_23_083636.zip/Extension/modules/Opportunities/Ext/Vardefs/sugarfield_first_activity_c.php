<?php
 // created: 2015-10-25 08:51:27
$dictionary['Opportunity']['fields']['first_activity_c']['labelValue']='First Activity';

 ?>