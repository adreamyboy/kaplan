<?php
 // created: 2015-02-07 21:39:41
$dictionary['GI_Surveys']['fields']['header_text_c']['labelValue']='Header Text';

 ?>