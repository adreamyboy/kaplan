<?php
 // created: 2014-06-01 20:21:50
$dictionary['GI_Credit_Notes']['fields']['amount_refunded_c']['labelValue']='Amount Refunded';

 ?>