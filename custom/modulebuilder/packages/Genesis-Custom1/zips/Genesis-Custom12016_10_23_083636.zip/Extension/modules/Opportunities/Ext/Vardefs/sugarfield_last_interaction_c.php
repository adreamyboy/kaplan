<?php
 // created: 2016-01-23 19:37:03
$dictionary['Opportunity']['fields']['last_interaction_c']['labelValue']='Last Interaction';

 ?>