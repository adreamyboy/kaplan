<?php
 // created: 2015-01-27 22:18:37
$dictionary['Contact']['fields']['primary_address_city']['audited']=true;
$dictionary['Contact']['fields']['primary_address_city']['comments']='City for primary address';
$dictionary['Contact']['fields']['primary_address_city']['merge_filter']='disabled';

 ?>