<?php
 // created: 2016-10-12 23:23:06
$dictionary['Contact']['fields']['do_not_sms_c']['labelValue']='Do Not SMS';

 ?>