<?php
 // created: 2015-01-27 22:19:11
$dictionary['Contact']['fields']['primary_address_country']['audited']=true;
$dictionary['Contact']['fields']['primary_address_country']['comments']='Country for primary address';
$dictionary['Contact']['fields']['primary_address_country']['merge_filter']='disabled';

 ?>