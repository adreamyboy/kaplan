<?php
 // created: 2014-11-20 05:17:15
$dictionary['User']['fields']['description']['merge_filter']='disabled';
$dictionary['User']['fields']['description']['rows']='4';
$dictionary['User']['fields']['description']['cols']='20';

 ?>