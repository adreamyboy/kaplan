<?php
 // created: 2014-06-18 14:02:42
$dictionary['User']['fields']['title']['merge_filter']='disabled';

 ?>