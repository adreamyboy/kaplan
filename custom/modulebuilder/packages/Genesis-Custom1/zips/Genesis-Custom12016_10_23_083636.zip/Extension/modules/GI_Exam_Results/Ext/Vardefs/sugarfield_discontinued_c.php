<?php
 // created: 2015-07-08 05:49:25
$dictionary['GI_Exam_Results']['fields']['discontinued_c']['labelValue']='Discontinued';

 ?>