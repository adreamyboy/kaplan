<?php
// created: 2014-05-29 06:25:07
$dictionary["Opportunity"]["fields"]["opportunities_gi_payments_1"] = array (
  'name' => 'opportunities_gi_payments_1',
  'type' => 'link',
  'relationship' => 'opportunities_gi_payments_1',
  'source' => 'non-db',
  'module' => 'GI_Payments',
  'bean_name' => 'GI_Payments',
  'side' => 'right',
  'vname' => 'LBL_OPPORTUNITIES_GI_PAYMENTS_1_FROM_GI_PAYMENTS_TITLE',
);
