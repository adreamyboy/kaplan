<?php
 // created: 2014-11-11 02:53:00
$dictionary['GI_Discounts']['fields']['expires_on_days_c']['options']='numeric_range_search_dom';
$dictionary['GI_Discounts']['fields']['expires_on_days_c']['labelValue']='Expires on (Days)';
$dictionary['GI_Discounts']['fields']['expires_on_days_c']['enable_range_search']='1';

 ?>