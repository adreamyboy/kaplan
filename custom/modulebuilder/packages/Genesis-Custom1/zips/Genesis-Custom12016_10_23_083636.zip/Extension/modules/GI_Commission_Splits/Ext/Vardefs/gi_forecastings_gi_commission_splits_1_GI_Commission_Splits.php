<?php
// created: 2015-05-17 08:00:31
$dictionary["GI_Commission_Splits"]["fields"]["gi_forecastings_gi_commission_splits_1"] = array (
  'name' => 'gi_forecastings_gi_commission_splits_1',
  'type' => 'link',
  'relationship' => 'gi_forecastings_gi_commission_splits_1',
  'source' => 'non-db',
  'module' => 'GI_Forecastings',
  'bean_name' => 'GI_Forecastings',
  'vname' => 'LBL_GI_FORECASTINGS_GI_COMMISSION_SPLITS_1_FROM_GI_FORECASTINGS_TITLE',
  'id_name' => 'gi_forecastings_gi_commission_splits_1gi_forecastings_ida',
);
$dictionary["GI_Commission_Splits"]["fields"]["gi_forecastings_gi_commission_splits_1_name"] = array (
  'name' => 'gi_forecastings_gi_commission_splits_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_GI_FORECASTINGS_GI_COMMISSION_SPLITS_1_FROM_GI_FORECASTINGS_TITLE',
  'save' => true,
  'id_name' => 'gi_forecastings_gi_commission_splits_1gi_forecastings_ida',
  'link' => 'gi_forecastings_gi_commission_splits_1',
  'table' => 'gi_forecastings',
  'module' => 'GI_Forecastings',
  'rname' => 'name',
);
$dictionary["GI_Commission_Splits"]["fields"]["gi_forecastings_gi_commission_splits_1gi_forecastings_ida"] = array (
  'name' => 'gi_forecastings_gi_commission_splits_1gi_forecastings_ida',
  'type' => 'link',
  'relationship' => 'gi_forecastings_gi_commission_splits_1',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_GI_FORECASTINGS_GI_COMMISSION_SPLITS_1_FROM_GI_COMMISSION_SPLITS_TITLE',
);
