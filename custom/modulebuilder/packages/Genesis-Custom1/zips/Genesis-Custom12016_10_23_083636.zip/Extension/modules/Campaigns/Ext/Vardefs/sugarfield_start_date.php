<?php
 // created: 2014-06-17 06:55:12
$dictionary['Campaign']['fields']['start_date']['display_default']='now';
$dictionary['Campaign']['fields']['start_date']['required']=true;
$dictionary['Campaign']['fields']['start_date']['comments']='Starting date of the campaign';
$dictionary['Campaign']['fields']['start_date']['merge_filter']='disabled';

 ?>