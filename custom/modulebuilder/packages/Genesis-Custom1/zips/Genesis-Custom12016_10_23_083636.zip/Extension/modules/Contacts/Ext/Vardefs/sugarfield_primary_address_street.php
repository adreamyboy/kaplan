<?php
 // created: 2015-01-27 22:18:26
$dictionary['Contact']['fields']['primary_address_street']['audited']=true;
$dictionary['Contact']['fields']['primary_address_street']['comments']='Street address for primary address';
$dictionary['Contact']['fields']['primary_address_street']['merge_filter']='disabled';

 ?>