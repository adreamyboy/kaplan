<?php
 // created: 2014-11-11 02:54:28
$dictionary['GI_Discounts']['fields']['rate_c']['labelValue']='Rate';

 ?>