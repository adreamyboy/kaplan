<?php
 // created: 2014-06-08 20:49:14
$dictionary['Opportunity']['fields']['total_unpaid_c']['labelValue']='Total Unpaid';

 ?>