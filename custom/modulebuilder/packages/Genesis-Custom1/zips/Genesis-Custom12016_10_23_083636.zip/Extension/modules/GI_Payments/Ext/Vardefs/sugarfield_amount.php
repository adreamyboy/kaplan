<?php
 // created: 2014-06-26 22:28:57
$dictionary['GI_Payments']['fields']['amount']['audited']=true;

 ?>