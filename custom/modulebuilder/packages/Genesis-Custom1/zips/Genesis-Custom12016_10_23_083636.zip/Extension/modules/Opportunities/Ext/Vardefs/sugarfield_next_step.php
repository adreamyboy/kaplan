<?php
 // created: 2015-10-25 08:53:00
$dictionary['Opportunity']['fields']['next_step']['comments']='The next step in the sales process';
$dictionary['Opportunity']['fields']['next_step']['merge_filter']='disabled';

 ?>