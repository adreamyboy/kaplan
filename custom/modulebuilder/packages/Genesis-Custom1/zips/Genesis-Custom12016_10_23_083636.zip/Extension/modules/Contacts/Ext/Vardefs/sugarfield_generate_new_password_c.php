<?php
 // created: 2014-12-09 10:59:42
$dictionary['Contact']['fields']['generate_new_password_c']['labelValue']='Generate New Password?';
$dictionary['Contact']['fields']['generate_new_password_c']['massupdate']=true;

 ?>