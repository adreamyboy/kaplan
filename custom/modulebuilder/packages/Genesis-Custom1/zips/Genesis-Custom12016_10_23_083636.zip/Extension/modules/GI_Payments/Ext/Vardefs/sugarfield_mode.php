<?php
 // created: 2014-08-30 11:41:27
$dictionary['GI_Payments']['fields']['mode']['audited']=true;

 ?>