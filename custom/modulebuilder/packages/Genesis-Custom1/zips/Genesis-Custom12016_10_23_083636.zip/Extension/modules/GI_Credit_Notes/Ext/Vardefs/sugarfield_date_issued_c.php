<?php
 // created: 2014-05-29 08:25:37
$dictionary['GI_Credit_Notes']['fields']['date_issued_c']['labelValue']='Date Issued';

 ?>