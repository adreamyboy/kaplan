<?php
// created: 2015-11-11 03:50:09
$dictionary["GI_Line_Items_Mass_Creator"]["fields"]["gi_line_items_mass_creator_gi_products_1"] = array (
  'name' => 'gi_line_items_mass_creator_gi_products_1',
  'type' => 'link',
  'relationship' => 'gi_line_items_mass_creator_gi_products_1',
  'source' => 'non-db',
  'module' => 'GI_Products',
  'bean_name' => 'GI_Products',
  'vname' => 'LBL_GI_LINE_ITEMS_MASS_CREATOR_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
);
