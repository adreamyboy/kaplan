<?php
//auto-generated file DO NOT EDIT
$layout_defs['Campaigns']['subpanel_setup']['emailmarketing']['override_subpanel_name'] = 'Campaign_subpanel_emailmarketing';
?>