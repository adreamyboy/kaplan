<?php
 // created: 2016-02-02 11:35:36
$dictionary['GI_Referrals']['fields']['referring_person_email_c']['labelValue']='Referring Person Email';

 ?>