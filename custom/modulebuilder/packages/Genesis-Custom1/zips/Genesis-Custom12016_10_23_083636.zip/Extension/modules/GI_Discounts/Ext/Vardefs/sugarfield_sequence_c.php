<?php
 // created: 2014-12-28 03:37:23
$dictionary['GI_Discounts']['fields']['sequence_c']['labelValue']='Sequence';

 ?>