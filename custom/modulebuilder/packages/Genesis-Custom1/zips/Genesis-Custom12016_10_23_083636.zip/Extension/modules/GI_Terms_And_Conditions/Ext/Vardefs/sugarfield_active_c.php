<?php
 // created: 2015-12-13 02:11:37
$dictionary['GI_Terms_And_Conditions']['fields']['active_c']['labelValue']='Active';

 ?>