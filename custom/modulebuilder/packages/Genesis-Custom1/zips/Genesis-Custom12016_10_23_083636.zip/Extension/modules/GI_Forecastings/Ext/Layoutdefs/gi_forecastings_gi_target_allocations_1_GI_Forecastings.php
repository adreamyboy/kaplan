<?php
 // created: 2015-05-17 08:22:06
$layout_defs["GI_Forecastings"]["subpanel_setup"]['gi_forecastings_gi_target_allocations_1'] = array (
  'order' => 200,
  'module' => 'GI_Target_Allocations',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_FORECASTINGS_GI_TARGET_ALLOCATIONS_1_FROM_GI_TARGET_ALLOCATIONS_TITLE',
  'get_subpanel_data' => 'gi_forecastings_gi_target_allocations_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
