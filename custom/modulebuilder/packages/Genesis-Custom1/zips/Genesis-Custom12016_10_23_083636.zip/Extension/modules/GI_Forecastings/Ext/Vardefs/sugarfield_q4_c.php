<?php
 // created: 2015-05-17 07:55:23
$dictionary['GI_Forecastings']['fields']['q4_c']['labelValue']='Q4';

 ?>