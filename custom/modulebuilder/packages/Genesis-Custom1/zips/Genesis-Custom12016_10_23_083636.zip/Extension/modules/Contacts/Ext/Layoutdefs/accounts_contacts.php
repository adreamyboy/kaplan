<?php
 // created: 2014-05-06 12:41:33
$layout_defs["Contacts"]["subpanel_setup"]['accounts_contacts'] = array (
  'order' => 200,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ACCOUNTS_SUBPANEL_TITLE',
  'get_subpanel_data' => 'accounts',
  'top_buttons' => 
  array (
    /*
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
    */
  ),
);
