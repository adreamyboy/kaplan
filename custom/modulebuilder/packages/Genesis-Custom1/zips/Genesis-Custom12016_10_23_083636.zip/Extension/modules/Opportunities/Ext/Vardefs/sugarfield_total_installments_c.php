<?php
 // created: 2014-08-16 17:39:59
$dictionary['Opportunity']['fields']['total_installments_c']['labelValue']='Total Installments';

 ?>