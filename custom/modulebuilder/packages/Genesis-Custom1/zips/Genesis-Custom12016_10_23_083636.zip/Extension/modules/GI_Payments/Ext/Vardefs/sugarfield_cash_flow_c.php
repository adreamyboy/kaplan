<?php
 // created: 2014-06-26 22:35:47
$dictionary['GI_Payments']['fields']['cash_flow_c']['labelValue']='Cash Flow';

 ?>