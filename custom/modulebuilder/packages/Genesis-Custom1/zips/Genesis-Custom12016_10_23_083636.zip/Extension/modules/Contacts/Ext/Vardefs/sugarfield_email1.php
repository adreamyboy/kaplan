<?php
 // created: 2015-03-25 11:03:52
$dictionary['Contact']['fields']['email1']['audited']=true;
$dictionary['Contact']['fields']['email1']['merge_filter']='disabled';
$dictionary['Contact']['fields']['email1']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['email1']['duplicate_merge_dom_value']='1';

 ?>