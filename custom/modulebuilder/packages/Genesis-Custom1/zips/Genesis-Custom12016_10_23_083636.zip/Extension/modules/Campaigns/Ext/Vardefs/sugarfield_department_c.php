<?php
 // created: 2014-06-17 06:54:05
$dictionary['Campaign']['fields']['department_c']['labelValue']='Department';

 ?>