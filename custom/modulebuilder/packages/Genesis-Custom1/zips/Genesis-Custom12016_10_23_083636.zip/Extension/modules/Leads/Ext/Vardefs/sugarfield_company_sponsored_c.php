<?php
 // created: 2014-06-23 09:20:31
$dictionary['Lead']['fields']['company_sponsored_c']['labelValue']='Company Sponsored';

 ?>