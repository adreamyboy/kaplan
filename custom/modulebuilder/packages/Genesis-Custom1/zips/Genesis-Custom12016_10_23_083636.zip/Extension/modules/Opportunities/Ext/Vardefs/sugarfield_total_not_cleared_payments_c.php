<?php
 // created: 2014-07-02 08:51:27
$dictionary['Opportunity']['fields']['total_not_cleared_payments_c']['labelValue']='Total Not Cleared Payments';

 ?>