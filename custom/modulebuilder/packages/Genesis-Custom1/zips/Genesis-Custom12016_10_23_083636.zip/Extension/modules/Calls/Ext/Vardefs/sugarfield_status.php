<?php
 // created: 2015-10-29 06:57:23
$dictionary['Call']['fields']['status']['audited']=true;
$dictionary['Call']['fields']['status']['comments']='The status of the call (Held, Not Held, etc.)';
$dictionary['Call']['fields']['status']['merge_filter']='disabled';

 ?>