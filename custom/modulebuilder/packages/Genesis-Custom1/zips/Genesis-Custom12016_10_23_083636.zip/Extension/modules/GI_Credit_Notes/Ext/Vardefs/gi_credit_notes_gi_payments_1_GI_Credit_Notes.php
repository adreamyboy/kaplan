<?php
// created: 2014-06-01 17:38:34
$dictionary["GI_Credit_Notes"]["fields"]["gi_credit_notes_gi_payments_1"] = array (
  'name' => 'gi_credit_notes_gi_payments_1',
  'type' => 'link',
  'relationship' => 'gi_credit_notes_gi_payments_1',
  'source' => 'non-db',
  'module' => 'GI_Payments',
  'bean_name' => 'GI_Payments',
  'side' => 'right',
  'vname' => 'LBL_GI_CREDIT_NOTES_GI_PAYMENTS_1_FROM_GI_PAYMENTS_TITLE',
);
