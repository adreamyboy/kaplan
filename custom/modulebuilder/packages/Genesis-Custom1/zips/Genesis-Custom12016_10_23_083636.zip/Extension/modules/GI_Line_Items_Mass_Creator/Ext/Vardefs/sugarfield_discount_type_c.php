<?php
 // created: 2015-11-11 09:08:38
$dictionary['GI_Line_Items_Mass_Creator']['fields']['discount_type_c']['labelValue']='Discount Type';

 ?>