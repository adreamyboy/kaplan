<?php
 // created: 2015-11-11 03:51:31
$dictionary['GI_Line_Items_Mass_Creator']['fields']['campaign_c']['labelValue']='Campaign';

 ?>