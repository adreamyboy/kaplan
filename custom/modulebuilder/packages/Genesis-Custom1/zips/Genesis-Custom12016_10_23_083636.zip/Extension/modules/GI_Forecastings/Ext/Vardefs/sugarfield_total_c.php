<?php
 // created: 2015-06-15 23:13:08
$dictionary['GI_Forecastings']['fields']['total_c']['labelValue']='Total';

 ?>