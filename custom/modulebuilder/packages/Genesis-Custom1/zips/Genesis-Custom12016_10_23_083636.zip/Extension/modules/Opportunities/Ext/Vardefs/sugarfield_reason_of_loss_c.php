<?php
 // created: 2016-07-21 04:32:55
$dictionary['Opportunity']['fields']['reason_of_loss_c']['labelValue']='Reason of Loss';

 ?>