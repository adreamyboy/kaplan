<?php
 // created: 2015-07-01 01:17:32
$dictionary['GI_Target_Allocations']['fields']['q3_amount_c']['labelValue']='Q3 Amount';

 ?>