<?php
 // created: 2015-03-25 11:03:25
$dictionary['Contact']['fields']['first_name']['audited']=true;
$dictionary['Contact']['fields']['first_name']['comments']='First name of the contact';
$dictionary['Contact']['fields']['first_name']['merge_filter']='disabled';
$dictionary['Contact']['fields']['first_name']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['first_name']['duplicate_merge_dom_value']='1';

 ?>