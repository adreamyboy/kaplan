<?php
 // created: 2015-10-29 06:55:57
$dictionary['Task']['fields']['status']['audited']=true;
$dictionary['Task']['fields']['status']['merge_filter']='disabled';

 ?>