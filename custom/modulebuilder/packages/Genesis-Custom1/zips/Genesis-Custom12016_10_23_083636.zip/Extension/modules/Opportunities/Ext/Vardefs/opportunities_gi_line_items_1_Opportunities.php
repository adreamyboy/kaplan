<?php
// created: 2014-05-06 12:42:35
$dictionary["Opportunity"]["fields"]["opportunities_gi_line_items_1"] = array (
  'name' => 'opportunities_gi_line_items_1',
  'type' => 'link',
  'relationship' => 'opportunities_gi_line_items_1',
  'source' => 'non-db',
  'module' => 'GI_Line_Items',
  'bean_name' => 'GI_Line_Items',
  'side' => 'right',
  'vname' => 'LBL_OPPORTUNITIES_GI_LINE_ITEMS_1_FROM_GI_LINE_ITEMS_TITLE',
);
