<?php
 // created: 2014-11-11 02:53:39
$dictionary['GI_Discounts']['fields']['is_combo_c']['labelValue']='Is Combo';

 ?>