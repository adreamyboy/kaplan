<?php
 // created: 2016-02-02 11:35:24
$dictionary['GI_Referrals']['fields']['referring_person_first_name_c']['labelValue']='Referring Person First Name';

 ?>