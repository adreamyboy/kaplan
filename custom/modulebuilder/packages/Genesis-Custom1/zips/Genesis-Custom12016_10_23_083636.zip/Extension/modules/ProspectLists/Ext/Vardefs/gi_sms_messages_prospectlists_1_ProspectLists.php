<?php
// created: 2014-10-12 04:21:20
$dictionary["ProspectList"]["fields"]["gi_sms_messages_prospectlists_1"] = array (
  'name' => 'gi_sms_messages_prospectlists_1',
  'type' => 'link',
  'relationship' => 'gi_sms_messages_prospectlists_1',
  'source' => 'non-db',
  'module' => 'GI_SMS_Messages',
  'bean_name' => 'GI_SMS_Messages',
  'vname' => 'LBL_GI_SMS_MESSAGES_PROSPECTLISTS_1_FROM_GI_SMS_MESSAGES_TITLE',
);
