<?php
// created: 2015-02-07 19:56:31
$dictionary["GI_Surveys"]["fields"]["gi_surveys_gi_questions_1"] = array (
  'name' => 'gi_surveys_gi_questions_1',
  'type' => 'link',
  'relationship' => 'gi_surveys_gi_questions_1',
  'source' => 'non-db',
  'module' => 'GI_Questions',
  'bean_name' => 'GI_Questions',
  'vname' => 'LBL_GI_SURVEYS_GI_QUESTIONS_1_FROM_GI_QUESTIONS_TITLE',
);
