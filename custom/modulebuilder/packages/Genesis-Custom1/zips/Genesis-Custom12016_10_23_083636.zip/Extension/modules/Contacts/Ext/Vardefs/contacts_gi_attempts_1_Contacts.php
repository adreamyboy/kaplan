<?php
// created: 2015-02-07 20:09:13
$dictionary["Contact"]["fields"]["contacts_gi_attempts_1"] = array (
  'name' => 'contacts_gi_attempts_1',
  'type' => 'link',
  'relationship' => 'contacts_gi_attempts_1',
  'source' => 'non-db',
  'module' => 'GI_Attempts',
  'bean_name' => 'GI_Attempts',
  'side' => 'right',
  'vname' => 'LBL_CONTACTS_GI_ATTEMPTS_1_FROM_GI_ATTEMPTS_TITLE',
);
