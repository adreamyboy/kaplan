<?php
 // created: 2014-12-27 10:42:28
$dictionary['Contact']['fields']['password_c']['labelValue']='Password';

 ?>