<?php
 // created: 2016-05-18 14:45:41
$dictionary['Lead']['fields']['company_c']['labelValue']='Company (experimental - do not use)';

 ?>