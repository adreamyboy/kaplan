<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['contacts_gi_line_items_1']['override_subpanel_name'] = 'Contact_subpanel_contacts_gi_line_items_1';
?>