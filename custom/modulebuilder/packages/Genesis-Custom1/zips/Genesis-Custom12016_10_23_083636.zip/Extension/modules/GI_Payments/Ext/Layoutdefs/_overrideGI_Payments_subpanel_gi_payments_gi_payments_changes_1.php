<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Payments']['subpanel_setup']['gi_payments_gi_payments_changes_1']['override_subpanel_name'] = 'GI_Payments_subpanel_gi_payments_gi_payments_changes_1';
?>