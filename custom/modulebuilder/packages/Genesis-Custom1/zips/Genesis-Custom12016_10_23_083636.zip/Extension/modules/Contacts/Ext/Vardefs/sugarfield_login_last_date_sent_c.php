<?php
 // created: 2014-12-27 10:42:54
$dictionary['Contact']['fields']['login_last_date_sent_c']['labelValue']='Login Last Date Sent';

 ?>