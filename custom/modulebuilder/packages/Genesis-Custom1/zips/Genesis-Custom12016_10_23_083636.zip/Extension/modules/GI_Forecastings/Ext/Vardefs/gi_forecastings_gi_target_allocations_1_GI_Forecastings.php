<?php
// created: 2015-05-17 08:22:06
$dictionary["GI_Forecastings"]["fields"]["gi_forecastings_gi_target_allocations_1"] = array (
  'name' => 'gi_forecastings_gi_target_allocations_1',
  'type' => 'link',
  'relationship' => 'gi_forecastings_gi_target_allocations_1',
  'source' => 'non-db',
  'module' => 'GI_Target_Allocations',
  'bean_name' => 'GI_Target_Allocations',
  'side' => 'right',
  'vname' => 'LBL_GI_FORECASTINGS_GI_TARGET_ALLOCATIONS_1_FROM_GI_TARGET_ALLOCATIONS_TITLE',
);
