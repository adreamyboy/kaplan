<?php
// created: 2015-05-17 07:59:51
$dictionary["GI_Forecastings"]["fields"]["gi_forecastings_gi_commission_criteria_1"] = array (
  'name' => 'gi_forecastings_gi_commission_criteria_1',
  'type' => 'link',
  'relationship' => 'gi_forecastings_gi_commission_criteria_1',
  'source' => 'non-db',
  'module' => 'GI_Commission_Criteria',
  'bean_name' => 'GI_Commission_Criteria',
  'side' => 'right',
  'vname' => 'LBL_GI_FORECASTINGS_GI_COMMISSION_CRITERIA_1_FROM_GI_COMMISSION_CRITERIA_TITLE',
);
