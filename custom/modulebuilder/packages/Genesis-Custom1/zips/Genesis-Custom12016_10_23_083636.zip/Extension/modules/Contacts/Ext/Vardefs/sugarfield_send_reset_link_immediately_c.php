<?php
 // created: 2015-01-14 05:48:45
$dictionary['Contact']['fields']['send_reset_link_immediately_c']['labelValue']='Send Reset Link Immediately?';

 ?>