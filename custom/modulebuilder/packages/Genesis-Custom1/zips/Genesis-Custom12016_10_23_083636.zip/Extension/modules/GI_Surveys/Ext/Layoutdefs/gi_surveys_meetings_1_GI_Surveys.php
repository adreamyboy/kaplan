<?php
 // created: 2015-10-22 10:20:56
$layout_defs["GI_Surveys"]["subpanel_setup"]['gi_surveys_meetings_1'] = array (
  'order' => 100,
  'module' => 'Meetings',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_SURVEYS_MEETINGS_1_FROM_MEETINGS_TITLE',
  'get_subpanel_data' => 'gi_surveys_meetings_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
