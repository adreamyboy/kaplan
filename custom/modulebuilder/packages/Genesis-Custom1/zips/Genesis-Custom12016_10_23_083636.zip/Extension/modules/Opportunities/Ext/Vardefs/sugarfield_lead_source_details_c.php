<?php
 // created: 2015-06-18 06:54:57
$dictionary['Opportunity']['fields']['lead_source_details_c']['labelValue']='Lead Source Details';

 ?>