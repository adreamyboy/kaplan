<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Line_Items_Mass_Creator']['subpanel_setup']['gi_line_items_mass_creator_gi_products_1']['override_subpanel_name'] = 'GI_Line_Items_Mass_Creator_subpanel_gi_line_items_mass_creator_gi_products_1';
?>