<?php
 // created: 2015-10-22 07:25:18
$dictionary['GI_Mobile_Registrations']['fields']['device_os_c']['labelValue']='Device OS';

 ?>