<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Forecastings']['subpanel_setup']['gi_forecastings_gi_commission_criteria_1']['override_subpanel_name'] = 'GI_Forecastings_subpanel_gi_forecastings_gi_commission_criteria_1';
?>