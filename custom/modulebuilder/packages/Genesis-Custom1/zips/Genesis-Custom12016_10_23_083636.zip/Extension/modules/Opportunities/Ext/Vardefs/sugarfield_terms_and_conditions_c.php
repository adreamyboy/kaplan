<?php
 // created: 2015-12-13 03:17:25
$dictionary['Opportunity']['fields']['terms_and_conditions_c']['labelValue']='Terms & Conditions';

 ?>