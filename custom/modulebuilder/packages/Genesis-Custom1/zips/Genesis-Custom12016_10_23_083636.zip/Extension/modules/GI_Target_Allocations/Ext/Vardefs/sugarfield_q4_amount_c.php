<?php
 // created: 2015-07-01 01:18:21
$dictionary['GI_Target_Allocations']['fields']['q4_amount_c']['labelValue']='Q4 Amount';

 ?>