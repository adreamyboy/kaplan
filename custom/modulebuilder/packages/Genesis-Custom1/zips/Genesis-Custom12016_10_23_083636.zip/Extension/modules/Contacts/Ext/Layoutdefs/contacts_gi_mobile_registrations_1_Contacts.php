<?php
 // created: 2015-10-22 07:35:50
$layout_defs["Contacts"]["subpanel_setup"]['contacts_gi_mobile_registrations_1'] = array (
  'order' => 100,
  'module' => 'GI_Mobile_Registrations',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CONTACTS_GI_MOBILE_REGISTRATIONS_1_FROM_GI_MOBILE_REGISTRATIONS_TITLE',
  'get_subpanel_data' => 'contacts_gi_mobile_registrations_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
