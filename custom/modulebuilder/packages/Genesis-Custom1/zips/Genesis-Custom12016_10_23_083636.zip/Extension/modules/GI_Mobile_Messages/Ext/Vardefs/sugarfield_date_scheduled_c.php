<?php
 // created: 2015-10-22 07:28:00
$dictionary['GI_Mobile_Messages']['fields']['date_scheduled_c']['options']='date_range_search_dom';
$dictionary['GI_Mobile_Messages']['fields']['date_scheduled_c']['labelValue']='Date/Time Scheduled';
$dictionary['GI_Mobile_Messages']['fields']['date_scheduled_c']['enable_range_search']='1';

 ?>