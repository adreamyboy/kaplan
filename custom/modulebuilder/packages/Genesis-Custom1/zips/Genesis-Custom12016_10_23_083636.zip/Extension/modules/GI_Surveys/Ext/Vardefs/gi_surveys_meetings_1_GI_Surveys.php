<?php
// created: 2015-10-22 10:20:56
$dictionary["GI_Surveys"]["fields"]["gi_surveys_meetings_1"] = array (
  'name' => 'gi_surveys_meetings_1',
  'type' => 'link',
  'relationship' => 'gi_surveys_meetings_1',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'side' => 'right',
  'vname' => 'LBL_GI_SURVEYS_MEETINGS_1_FROM_MEETINGS_TITLE',
);
