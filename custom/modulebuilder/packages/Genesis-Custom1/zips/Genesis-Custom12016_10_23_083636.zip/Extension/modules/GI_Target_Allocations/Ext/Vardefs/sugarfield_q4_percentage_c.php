<?php
 // created: 2015-07-01 01:29:12
$dictionary['GI_Target_Allocations']['fields']['q4_percentage_c']['labelValue']='Q4 %';

 ?>