<?php
 // created: 2015-10-29 06:56:50
$dictionary['Call']['fields']['date_end']['audited']=true;
$dictionary['Call']['fields']['date_end']['comments']='Date is which call is scheduled to (or did) end';
$dictionary['Call']['fields']['date_end']['merge_filter']='disabled';

 ?>