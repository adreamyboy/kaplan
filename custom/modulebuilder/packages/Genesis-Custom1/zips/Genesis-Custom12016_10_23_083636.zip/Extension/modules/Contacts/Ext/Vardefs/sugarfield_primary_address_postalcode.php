<?php
 // created: 2015-01-27 22:18:59
$dictionary['Contact']['fields']['primary_address_postalcode']['len']='50';
$dictionary['Contact']['fields']['primary_address_postalcode']['comments']='Postal code for primary address';
$dictionary['Contact']['fields']['primary_address_postalcode']['merge_filter']='disabled';
$dictionary['Contact']['fields']['primary_address_postalcode']['audited']=true;

 ?>