<?php
 // created: 2015-10-30 07:35:51
$dictionary['Contact']['fields']['is_instructor_c']['labelValue']='Is Instructor';

 ?>