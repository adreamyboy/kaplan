<?php
 // created: 2015-07-01 01:29:54
$dictionary['GI_Target_Allocations']['fields']['q3_percentage_c']['labelValue']='Q3 %';

 ?>