<?php
 // created: 2014-06-28 11:16:08
$dictionary['GI_Payments']['fields']['date_entered']['audited']=false;
$dictionary['GI_Payments']['fields']['date_entered']['comments']='Date record created';
$dictionary['GI_Payments']['fields']['date_entered']['merge_filter']='disabled';

 ?>