<?php
 // created: 2016-02-02 11:35:59
$dictionary['GI_Referrals']['fields']['referred_person_mobile_c']['labelValue']='Referred Person Mobile';

 ?>