<?php
 // created: 2015-11-11 09:06:20
$dictionary['GI_Line_Items_Mass_Creator']['fields']['auto_discount_c']['labelValue']='Auto Discount?';

 ?>