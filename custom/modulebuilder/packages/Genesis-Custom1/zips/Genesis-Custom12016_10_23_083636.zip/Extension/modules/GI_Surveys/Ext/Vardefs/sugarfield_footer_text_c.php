<?php
 // created: 2015-02-07 21:39:59
$dictionary['GI_Surveys']['fields']['footer_text_c']['labelValue']='Footer Text';

 ?>