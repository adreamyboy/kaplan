<?php
// created: 2014-11-11 03:10:26
$dictionary["GI_Discounts"]["fields"]["gi_discounts_gi_products_catalog_1"] = array (
  'name' => 'gi_discounts_gi_products_catalog_1',
  'type' => 'link',
  'relationship' => 'gi_discounts_gi_products_catalog_1',
  'source' => 'non-db',
  'module' => 'GI_Products_Catalog',
  'bean_name' => 'GI_Products_Catalog',
  'vname' => 'LBL_GI_DISCOUNTS_GI_PRODUCTS_CATALOG_1_FROM_GI_PRODUCTS_CATALOG_TITLE',
);
