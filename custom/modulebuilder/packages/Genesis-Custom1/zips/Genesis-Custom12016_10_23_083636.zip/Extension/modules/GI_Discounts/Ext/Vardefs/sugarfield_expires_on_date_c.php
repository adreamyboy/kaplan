<?php
 // created: 2014-11-11 03:19:07
$dictionary['GI_Discounts']['fields']['expires_on_date_c']['options']='date_range_search_dom';
$dictionary['GI_Discounts']['fields']['expires_on_date_c']['labelValue']='Expires on (Date)';
$dictionary['GI_Discounts']['fields']['expires_on_date_c']['enable_range_search']='1';

 ?>