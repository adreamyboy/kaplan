<?php
 // created: 2016-01-23 19:35:53
$dictionary['Opportunity']['fields']['no_of_completed_interactions_c']['options']='numeric_range_search_dom';
$dictionary['Opportunity']['fields']['no_of_completed_interactions_c']['labelValue']='No. of Completed Interactions';
$dictionary['Opportunity']['fields']['no_of_completed_interactions_c']['enable_range_search']='1';

 ?>