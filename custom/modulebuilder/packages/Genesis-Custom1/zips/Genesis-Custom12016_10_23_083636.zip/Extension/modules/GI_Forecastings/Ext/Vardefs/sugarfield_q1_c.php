<?php
 // created: 2015-05-17 07:54:35
$dictionary['GI_Forecastings']['fields']['q1_c']['labelValue']='Q1';

 ?>