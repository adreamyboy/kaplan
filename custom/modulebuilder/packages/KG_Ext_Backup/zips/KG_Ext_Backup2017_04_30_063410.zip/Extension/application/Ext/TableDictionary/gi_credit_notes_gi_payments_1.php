<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_credit_notes_gi_payments_1MetaData.php');

?>