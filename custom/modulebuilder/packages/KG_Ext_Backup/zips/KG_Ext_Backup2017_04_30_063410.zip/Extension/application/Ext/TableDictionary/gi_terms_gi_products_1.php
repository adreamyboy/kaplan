<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_terms_gi_products_1MetaData.php');

?>