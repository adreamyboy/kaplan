<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_country_gi_locations_1MetaData.php');

?>