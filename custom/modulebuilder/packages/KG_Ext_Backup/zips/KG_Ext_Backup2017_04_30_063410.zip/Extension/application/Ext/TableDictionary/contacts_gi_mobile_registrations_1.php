<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_gi_mobile_registrations_1MetaData.php');

?>