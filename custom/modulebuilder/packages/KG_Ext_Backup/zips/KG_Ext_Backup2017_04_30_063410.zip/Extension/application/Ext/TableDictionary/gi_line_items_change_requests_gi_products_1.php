<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_line_items_change_requests_gi_products_1MetaData.php');

?>