<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_gi_line_items_1MetaData.php');

?>