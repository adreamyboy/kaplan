<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_discounts_prospectlists_1MetaData.php');

?>