<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/opportunities_gi_payments_1MetaData.php');

?>