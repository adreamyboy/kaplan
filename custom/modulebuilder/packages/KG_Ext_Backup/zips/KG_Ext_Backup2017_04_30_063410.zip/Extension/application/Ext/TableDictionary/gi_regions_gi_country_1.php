<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_regions_gi_country_1MetaData.php');

?>