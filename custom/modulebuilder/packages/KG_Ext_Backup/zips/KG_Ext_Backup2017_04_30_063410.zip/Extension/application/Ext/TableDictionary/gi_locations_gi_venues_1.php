<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_locations_gi_venues_1MetaData.php');

?>