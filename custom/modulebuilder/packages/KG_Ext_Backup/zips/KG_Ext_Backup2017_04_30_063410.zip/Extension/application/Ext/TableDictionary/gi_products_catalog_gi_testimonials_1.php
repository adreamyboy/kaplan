<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_products_catalog_gi_testimonials_1MetaData.php');

?>