<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/accounts_gi_credit_notes_1MetaData.php');

?>