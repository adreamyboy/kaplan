<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_products_gi_elearning_courses_1MetaData.php');

?>