<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/gi_line_items_mass_creator_notes_1MetaData.php');

?>