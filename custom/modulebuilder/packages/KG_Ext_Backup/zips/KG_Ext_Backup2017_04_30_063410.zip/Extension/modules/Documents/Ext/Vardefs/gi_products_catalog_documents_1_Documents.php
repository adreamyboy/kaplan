<?php
// created: 2014-11-12 12:38:15
$dictionary["Document"]["fields"]["gi_products_catalog_documents_1"] = array (
  'name' => 'gi_products_catalog_documents_1',
  'type' => 'link',
  'relationship' => 'gi_products_catalog_documents_1',
  'source' => 'non-db',
  'module' => 'GI_Products_Catalog',
  'bean_name' => 'GI_Products_Catalog',
  'vname' => 'LBL_GI_PRODUCTS_CATALOG_DOCUMENTS_1_FROM_GI_PRODUCTS_CATALOG_TITLE',
);
