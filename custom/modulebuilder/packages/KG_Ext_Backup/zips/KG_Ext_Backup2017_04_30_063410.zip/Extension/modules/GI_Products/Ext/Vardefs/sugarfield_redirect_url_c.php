<?php
 // created: 2016-05-18 18:02:50
$dictionary['GI_Products']['fields']['redirect_url_c']['labelValue']='Redirect URL (experimental)';

 ?>