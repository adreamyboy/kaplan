<?php
 // created: 2015-04-01 00:42:31
$dictionary['GI_Testimonials']['fields']['group_name_c']['labelValue']='Group Name';
$dictionary['GI_Testimonials']['fields']['group_name_c']['massupdate']=1;

 ?>