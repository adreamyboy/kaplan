<?php
 // created: 2015-07-07 12:51:03
$layout_defs["GI_Mobile_Messages"]["subpanel_setup"]['gi_mobile_messages_prospectlists_1'] = array (
  'order' => 100,
  'module' => 'ProspectLists',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_MOBILE_MESSAGES_PROSPECTLISTS_1_FROM_PROSPECTLISTS_TITLE',
  'get_subpanel_data' => 'gi_mobile_messages_prospectlists_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
