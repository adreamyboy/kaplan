<?php
 // created: 2014-06-17 07:50:31
$dictionary['Opportunity']['fields']['date_sync_with_quickbooks_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['date_sync_with_quickbooks_c']['labelValue']='Date Sync with QuickBooks';
$dictionary['Opportunity']['fields']['date_sync_with_quickbooks_c']['enable_range_search']='1';

 ?>