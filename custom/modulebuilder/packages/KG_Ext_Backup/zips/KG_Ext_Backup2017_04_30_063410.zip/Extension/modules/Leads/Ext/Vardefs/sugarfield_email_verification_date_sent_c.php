<?php
 // created: 2015-01-27 22:26:43
$dictionary['Lead']['fields']['email_verification_date_sent_c']['labelValue']='Email Verification Date Sent';

 ?>