<?php
 // created: 2015-10-22 07:30:37
$layout_defs["ProspectLists"]["subpanel_setup"]['gi_mobile_messages_prospectlists_1'] = array (
  'order' => 100,
  'module' => 'GI_Mobile_Messages',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_MOBILE_MESSAGES_PROSPECTLISTS_1_FROM_GI_MOBILE_MESSAGES_TITLE',
  'get_subpanel_data' => 'gi_mobile_messages_prospectlists_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
