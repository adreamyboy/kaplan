<?php
 // created: 2014-06-23 09:55:44
$dictionary['Opportunity']['fields']['company_sponsored_c']['labelValue']='Company Sponsored';

 ?>