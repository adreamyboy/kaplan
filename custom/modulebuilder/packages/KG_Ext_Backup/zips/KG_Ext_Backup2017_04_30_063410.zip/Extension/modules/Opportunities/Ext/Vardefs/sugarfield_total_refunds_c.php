<?php
 // created: 2014-05-29 07:30:04
$dictionary['Opportunity']['fields']['total_refunds_c']['labelValue']='Total Refunds';

 ?>