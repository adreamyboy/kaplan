<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Surveys']['subpanel_setup']['gi_surveys_meetings_1']['override_subpanel_name'] = 'GI_Surveys_subpanel_gi_surveys_meetings_1';
?>