<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Products']['subpanel_setup']['gi_products_gi_line_items_1']['override_subpanel_name'] = 'GI_Products_subpanel_gi_products_gi_line_items_1';
?>