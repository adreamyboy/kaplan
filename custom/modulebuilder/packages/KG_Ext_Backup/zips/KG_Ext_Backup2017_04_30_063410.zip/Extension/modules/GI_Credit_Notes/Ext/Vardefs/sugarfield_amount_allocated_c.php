<?php
 // created: 2014-06-01 18:37:35
$dictionary['GI_Credit_Notes']['fields']['amount_allocated_c']['labelValue']='Amount Allocated';

 ?>