<?php
// created: 2014-10-12 04:21:20
$dictionary["GI_SMS_Messages"]["fields"]["gi_sms_messages_prospectlists_1"] = array (
  'name' => 'gi_sms_messages_prospectlists_1',
  'type' => 'link',
  'relationship' => 'gi_sms_messages_prospectlists_1',
  'source' => 'non-db',
  'module' => 'ProspectLists',
  'bean_name' => 'ProspectList',
  'vname' => 'LBL_GI_SMS_MESSAGES_PROSPECTLISTS_1_FROM_PROSPECTLISTS_TITLE',
);
