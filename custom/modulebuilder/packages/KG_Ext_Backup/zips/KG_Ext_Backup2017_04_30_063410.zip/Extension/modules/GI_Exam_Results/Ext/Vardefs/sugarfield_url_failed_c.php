<?php
 // created: 2015-07-27 05:26:51
$dictionary['GI_Exam_Results']['fields']['url_failed_c']['labelValue']='URL Failed';

 ?>