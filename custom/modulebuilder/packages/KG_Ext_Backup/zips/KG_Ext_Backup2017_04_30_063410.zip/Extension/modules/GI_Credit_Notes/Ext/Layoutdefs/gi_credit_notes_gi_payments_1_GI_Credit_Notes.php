<?php
 // created: 2014-06-01 17:38:34
$layout_defs["GI_Credit_Notes"]["subpanel_setup"]['gi_credit_notes_gi_payments_1'] = array (
  'order' => 100,
  'module' => 'GI_Payments',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_CREDIT_NOTES_GI_PAYMENTS_1_FROM_GI_PAYMENTS_TITLE',
  'get_subpanel_data' => 'gi_credit_notes_gi_payments_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
