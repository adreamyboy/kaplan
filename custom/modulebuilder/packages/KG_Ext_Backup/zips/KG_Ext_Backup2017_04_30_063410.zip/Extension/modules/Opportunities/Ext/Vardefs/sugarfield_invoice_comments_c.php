<?php
 // created: 2014-05-08 09:24:54
$dictionary['Opportunity']['fields']['invoice_comments_c']['labelValue']='Invoice Comments';

 ?>