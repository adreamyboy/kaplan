<?php
 // created: 2015-09-22 02:17:34
$dictionary['GI_Line_Items']['fields']['status_c']['labelValue']='Status';

 ?>