<?php
 // created: 2014-05-08 10:32:40
$dictionary['GI_Products']['fields']['number_of_sessions_c']['labelValue']='Number of Sessions';

 ?>