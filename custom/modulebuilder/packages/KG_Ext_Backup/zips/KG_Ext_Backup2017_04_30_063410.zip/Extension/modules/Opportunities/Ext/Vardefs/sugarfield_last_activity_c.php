<?php
 // created: 2015-10-25 08:51:41
$dictionary['Opportunity']['fields']['last_activity_c']['labelValue']='Last Activity';

 ?>