<?php
 // created: 2015-02-17 00:47:54
$dictionary['GI_Testimonials']['fields']['status_c']['labelValue']='Status';
$dictionary['GI_Testimonials']['fields']['status_c']['massupdate']=1;

 ?>