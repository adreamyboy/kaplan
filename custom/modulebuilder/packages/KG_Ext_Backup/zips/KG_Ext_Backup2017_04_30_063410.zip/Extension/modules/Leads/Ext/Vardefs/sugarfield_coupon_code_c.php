<?php
 // created: 2016-11-24 05:28:58
$dictionary['Lead']['fields']['coupon_code_c']['labelValue']='Coupon Code';

 ?>