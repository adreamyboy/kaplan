<?php
// created: 2014-05-06 15:32:53
$dictionary["GI_Terms"]["fields"]["gi_terms_gi_products_1"] = array (
  'name' => 'gi_terms_gi_products_1',
  'type' => 'link',
  'relationship' => 'gi_terms_gi_products_1',
  'source' => 'non-db',
  'module' => 'GI_Products',
  'bean_name' => 'GI_Products',
  'side' => 'right',
  'vname' => 'LBL_GI_TERMS_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
);
