<?php
 // created: 2015-07-08 05:44:07
$layout_defs["GI_Exam_Results"]["subpanel_setup"]['gi_exam_results_gi_products_1'] = array (
  'order' => 100,
  'module' => 'GI_Products',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_EXAM_RESULTS_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
  'get_subpanel_data' => 'gi_exam_results_gi_products_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
