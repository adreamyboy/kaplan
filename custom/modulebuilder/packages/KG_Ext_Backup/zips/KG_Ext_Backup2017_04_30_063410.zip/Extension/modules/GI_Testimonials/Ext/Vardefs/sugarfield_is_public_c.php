<?php
 // created: 2015-03-25 03:58:19
$dictionary['GI_Testimonials']['fields']['is_public_c']['labelValue']='Is Public?';
$dictionary['GI_Testimonials']['fields']['is_public_c']['massupdate']=1;

 ?>