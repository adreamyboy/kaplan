<?php
// created: 2015-10-22 07:30:37
$dictionary["GI_Mobile_Messages"]["fields"]["gi_mobile_messages_prospectlists_1"] = array (
  'name' => 'gi_mobile_messages_prospectlists_1',
  'type' => 'link',
  'relationship' => 'gi_mobile_messages_prospectlists_1',
  'source' => 'non-db',
  'module' => 'ProspectLists',
  'bean_name' => 'ProspectList',
  'vname' => 'LBL_GI_MOBILE_MESSAGES_PROSPECTLISTS_1_FROM_PROSPECTLISTS_TITLE',
);
