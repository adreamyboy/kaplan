<?php
// created: 2014-11-11 03:01:02
$dictionary["ProspectList"]["fields"]["gi_discounts_prospectlists_1"] = array (
  'name' => 'gi_discounts_prospectlists_1',
  'type' => 'link',
  'relationship' => 'gi_discounts_prospectlists_1',
  'source' => 'non-db',
  'module' => 'GI_Discounts',
  'bean_name' => 'GI_Discounts',
  'vname' => 'LBL_GI_DISCOUNTS_PROSPECTLISTS_1_FROM_GI_DISCOUNTS_TITLE',
);
