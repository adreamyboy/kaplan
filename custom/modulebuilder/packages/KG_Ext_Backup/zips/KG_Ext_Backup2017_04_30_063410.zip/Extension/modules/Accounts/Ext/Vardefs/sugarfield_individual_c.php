<?php
 // created: 2014-12-09 00:28:47
$dictionary['Account']['fields']['individual_c']['labelValue']='Individual';

 ?>