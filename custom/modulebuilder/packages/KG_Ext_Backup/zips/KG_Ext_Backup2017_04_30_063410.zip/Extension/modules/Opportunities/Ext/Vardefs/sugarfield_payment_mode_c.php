<?php
 // created: 2015-01-10 22:45:40
$dictionary['Opportunity']['fields']['payment_mode_c']['labelValue']='Preferred Payment Mode';

 ?>