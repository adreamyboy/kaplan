<?php
 // created: 2014-08-05 04:09:39
$dictionary['Campaign']['fields']['show_on_web_c']['labelValue']='Show On Web';

 ?>