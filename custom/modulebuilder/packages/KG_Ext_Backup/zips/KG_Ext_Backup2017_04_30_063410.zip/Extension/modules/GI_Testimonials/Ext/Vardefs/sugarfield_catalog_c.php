<?php
 // created: 2015-03-25 04:28:59
$dictionary['GI_Testimonials']['fields']['catalog_c']['labelValue']='What course have you attended with us?';
$dictionary['GI_Testimonials']['fields']['catalog_c']['massupdate']=1;

 ?>