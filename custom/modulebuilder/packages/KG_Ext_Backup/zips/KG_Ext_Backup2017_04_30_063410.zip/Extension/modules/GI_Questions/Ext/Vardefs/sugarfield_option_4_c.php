<?php
 // created: 2015-02-07 20:15:11
$dictionary['GI_Questions']['fields']['option_4_c']['labelValue']='Option 4';

 ?>