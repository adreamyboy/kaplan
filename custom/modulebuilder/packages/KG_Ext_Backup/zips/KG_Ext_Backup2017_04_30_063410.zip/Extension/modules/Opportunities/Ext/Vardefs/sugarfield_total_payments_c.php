<?php
 // created: 2014-08-31 22:56:45
$dictionary['Opportunity']['fields']['total_payments_c']['labelValue']='Total Receipts';

 ?>