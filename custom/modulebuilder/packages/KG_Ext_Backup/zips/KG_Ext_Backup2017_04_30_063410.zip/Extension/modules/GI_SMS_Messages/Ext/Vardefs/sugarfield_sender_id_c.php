<?php
 // created: 2017-02-26 06:07:02
$dictionary['GI_SMS_Messages']['fields']['sender_id_c']['inline_edit']='1';
$dictionary['GI_SMS_Messages']['fields']['sender_id_c']['labelValue']='Sender ID';

 ?>