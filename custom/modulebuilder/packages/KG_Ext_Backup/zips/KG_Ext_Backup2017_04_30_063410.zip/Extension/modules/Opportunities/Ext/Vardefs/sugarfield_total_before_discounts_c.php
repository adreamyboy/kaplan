<?php
 // created: 2014-05-08 09:29:40
$dictionary['Opportunity']['fields']['total_before_discounts_c']['labelValue']='Total Before Discounts';

 ?>