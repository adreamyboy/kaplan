<?php
 // created: 2015-03-11 01:38:15
$dictionary['GI_Products']['fields']['capacity_c']['labelValue']='Maximum Capacity';

 ?>