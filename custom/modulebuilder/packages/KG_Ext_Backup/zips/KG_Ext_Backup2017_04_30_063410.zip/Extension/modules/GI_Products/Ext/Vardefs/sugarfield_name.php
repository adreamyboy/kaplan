<?php
 // created: 2014-09-30 03:53:42
$dictionary['GI_Products']['fields']['name']['required']=false;
$dictionary['GI_Products']['fields']['name']['importable']='true';
$dictionary['GI_Products']['fields']['name']['audited']=true;
$dictionary['GI_Products']['fields']['name']['duplicate_merge']='disabled';
$dictionary['GI_Products']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['GI_Products']['fields']['name']['full_text_search']=array (
);

 ?>