<?php
 // created: 2014-11-12 12:38:15
$layout_defs["Documents"]["subpanel_setup"]['gi_products_catalog_documents_1'] = array (
  'order' => 100,
  'module' => 'GI_Products_Catalog',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_PRODUCTS_CATALOG_DOCUMENTS_1_FROM_GI_PRODUCTS_CATALOG_TITLE',
  'get_subpanel_data' => 'gi_products_catalog_documents_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
