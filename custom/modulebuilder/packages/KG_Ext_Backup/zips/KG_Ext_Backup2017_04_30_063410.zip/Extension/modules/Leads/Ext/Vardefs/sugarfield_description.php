<?php
 // created: 2014-08-05 09:43:28
$dictionary['Lead']['fields']['description']['comments']='Full text of the note';
$dictionary['Lead']['fields']['description']['merge_filter']='disabled';

 ?>