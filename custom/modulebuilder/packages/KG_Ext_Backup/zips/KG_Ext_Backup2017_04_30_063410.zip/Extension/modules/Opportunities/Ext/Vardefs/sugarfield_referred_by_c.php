<?php
 // created: 2016-02-07 12:01:02
$dictionary['Opportunity']['fields']['referred_by_c']['labelValue']='Referred By';

 ?>