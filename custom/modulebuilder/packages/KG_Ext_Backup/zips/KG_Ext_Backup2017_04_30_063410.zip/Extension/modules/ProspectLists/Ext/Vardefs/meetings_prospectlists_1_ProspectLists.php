<?php
// created: 2014-10-13 13:30:33
$dictionary["ProspectList"]["fields"]["meetings_prospectlists_1"] = array (
  'name' => 'meetings_prospectlists_1',
  'type' => 'link',
  'relationship' => 'meetings_prospectlists_1',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_MEETINGS_PROSPECTLISTS_1_FROM_MEETINGS_TITLE',
);
