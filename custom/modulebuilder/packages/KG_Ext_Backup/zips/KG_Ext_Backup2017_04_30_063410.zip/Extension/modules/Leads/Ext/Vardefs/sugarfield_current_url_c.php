<?php
 // created: 2014-08-05 08:32:26
$dictionary['Lead']['fields']['current_url_c']['labelValue']='Current URL';

 ?>