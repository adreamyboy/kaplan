<?php
 // created: 2015-06-10 21:16:41
$dictionary['GI_Products']['fields']['hide_add_to_cart_c']['labelValue']='Hide (Add to Cart) in website';

 ?>