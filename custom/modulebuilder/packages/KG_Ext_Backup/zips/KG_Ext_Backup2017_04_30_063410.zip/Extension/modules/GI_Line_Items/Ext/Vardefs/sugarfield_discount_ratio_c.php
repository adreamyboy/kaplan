<?php
 // created: 2014-05-29 04:23:01
$dictionary['GI_Line_Items']['fields']['discount_ratio_c']['labelValue']='Discount Ratio';

 ?>