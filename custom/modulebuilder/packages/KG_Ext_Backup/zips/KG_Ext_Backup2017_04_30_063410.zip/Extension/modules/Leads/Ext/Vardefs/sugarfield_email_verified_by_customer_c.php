<?php
 // created: 2016-05-18 14:44:36
$dictionary['Lead']['fields']['email_verified_by_customer_c']['labelValue']='Email Verified By Customer (experimental - do not use)';

 ?>