<?php
 // created: 2015-07-12 14:59:43
$dictionary['GI_Products']['fields']['refund_expiry_terms_c']['labelValue']='Refund Expiry Terms';

 ?>