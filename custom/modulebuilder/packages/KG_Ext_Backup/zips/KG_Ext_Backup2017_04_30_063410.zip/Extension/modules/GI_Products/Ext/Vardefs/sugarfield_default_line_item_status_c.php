<?php
 // created: 2016-05-18 17:03:07
$dictionary['GI_Products']['fields']['default_line_item_status_c']['labelValue']='Default Line Item Status (experimental)';

 ?>