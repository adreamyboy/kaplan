<?php
 // created: 2015-02-07 20:14:03
$dictionary['GI_Questions']['fields']['option_1_c']['labelValue']='Option 1';

 ?>