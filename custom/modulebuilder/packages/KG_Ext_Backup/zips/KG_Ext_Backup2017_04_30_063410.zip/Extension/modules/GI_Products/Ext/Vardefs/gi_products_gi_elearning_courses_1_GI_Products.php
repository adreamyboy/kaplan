<?php
// created: 2015-08-19 23:06:30
$dictionary["GI_Products"]["fields"]["gi_products_gi_elearning_courses_1"] = array (
  'name' => 'gi_products_gi_elearning_courses_1',
  'type' => 'link',
  'relationship' => 'gi_products_gi_elearning_courses_1',
  'source' => 'non-db',
  'module' => 'GI_eLearning_Courses',
  'bean_name' => 'GI_eLearning_Courses',
  'vname' => 'LBL_GI_PRODUCTS_GI_ELEARNING_COURSES_1_FROM_GI_ELEARNING_COURSES_TITLE',
);
