<?php
// created: 2014-06-02 09:51:30
$dictionary["Account"]["fields"]["accounts_gi_products_1"] = array (
  'name' => 'accounts_gi_products_1',
  'type' => 'link',
  'relationship' => 'accounts_gi_products_1',
  'source' => 'non-db',
  'module' => 'GI_Products',
  'bean_name' => 'GI_Products',
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
);
