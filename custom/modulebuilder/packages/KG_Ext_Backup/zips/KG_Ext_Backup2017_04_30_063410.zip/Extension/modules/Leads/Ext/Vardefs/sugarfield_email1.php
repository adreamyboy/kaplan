<?php
 // created: 2015-02-01 00:20:09
$dictionary['Lead']['fields']['email1']['required']=false;
$dictionary['Lead']['fields']['email1']['merge_filter']='disabled';
$dictionary['Lead']['fields']['email1']['audited']=true;

 ?>