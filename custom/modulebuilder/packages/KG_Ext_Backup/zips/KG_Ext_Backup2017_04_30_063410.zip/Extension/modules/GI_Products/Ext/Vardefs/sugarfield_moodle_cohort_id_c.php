<?php
 // created: 2014-12-09 10:40:17
$dictionary['GI_Products']['fields']['moodle_cohort_id_c']['labelValue']='Moodle Cohort ID';

 ?>