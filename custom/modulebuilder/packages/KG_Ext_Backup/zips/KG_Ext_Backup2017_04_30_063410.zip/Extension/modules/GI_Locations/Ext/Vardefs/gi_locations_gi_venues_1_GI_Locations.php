<?php
// created: 2014-05-06 14:03:51
$dictionary["GI_Locations"]["fields"]["gi_locations_gi_venues_1"] = array (
  'name' => 'gi_locations_gi_venues_1',
  'type' => 'link',
  'relationship' => 'gi_locations_gi_venues_1',
  'source' => 'non-db',
  'module' => 'GI_Venues',
  'bean_name' => 'GI_Venues',
  'side' => 'right',
  'vname' => 'LBL_GI_LOCATIONS_GI_VENUES_1_FROM_GI_VENUES_TITLE',
);
