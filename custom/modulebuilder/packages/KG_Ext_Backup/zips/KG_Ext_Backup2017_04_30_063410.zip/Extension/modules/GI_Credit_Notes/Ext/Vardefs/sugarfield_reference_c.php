<?php
 // created: 2014-06-11 16:37:00
$dictionary['GI_Credit_Notes']['fields']['reference_c']['labelValue']='Reference';
$dictionary['GI_Credit_Notes']['fields']['reference_c']['autoinc_next']='1';
$dictionary['GI_Credit_Notes']['fields']['reference_c']['auto_increment']=true;

 ?>