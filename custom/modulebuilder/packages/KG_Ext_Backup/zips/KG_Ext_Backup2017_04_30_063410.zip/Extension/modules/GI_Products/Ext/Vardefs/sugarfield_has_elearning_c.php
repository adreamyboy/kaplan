<?php
 // created: 2014-12-09 10:41:05
$dictionary['GI_Products']['fields']['has_elearning_c']['labelValue']='Has eLearning';

 ?>