<?php
 // created: 2015-09-10 05:22:30
$dictionary['GI_Line_Items']['fields']['date_shipped_c']['options']='date_range_search_dom';
$dictionary['GI_Line_Items']['fields']['date_shipped_c']['labelValue']='Date Shipped';
$dictionary['GI_Line_Items']['fields']['date_shipped_c']['enable_range_search']='1';

 ?>