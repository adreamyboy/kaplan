<?php
 // created: 2015-10-25 04:16:57
$dictionary['Opportunity']['fields']['first_activity_date_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['first_activity_date_c']['labelValue']='First Activity Date';
$dictionary['Opportunity']['fields']['first_activity_date_c']['enable_range_search']='1';

 ?>