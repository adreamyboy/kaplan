<?php
 // created: 2014-06-28 09:49:32
$dictionary['GI_Products']['fields']['date_refund_expired_c']['labelValue']='Date Refund Expired';

 ?>