<?php
 // created: 2014-08-30 11:43:51
$dictionary['GI_Products']['fields']['code']['audited']=true;

 ?>