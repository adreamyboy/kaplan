<?php
 // created: 2015-10-29 06:55:41
$dictionary['Task']['fields']['date_start']['required']=true;
$dictionary['Task']['fields']['date_start']['merge_filter']='disabled';
$dictionary['Task']['fields']['date_start']['audited']=true;

 ?>