<?php
 // created: 2015-07-27 05:26:40
$dictionary['GI_Exam_Results']['fields']['url_did_not_appear_c']['labelValue']='URL Did Not Appear';

 ?>