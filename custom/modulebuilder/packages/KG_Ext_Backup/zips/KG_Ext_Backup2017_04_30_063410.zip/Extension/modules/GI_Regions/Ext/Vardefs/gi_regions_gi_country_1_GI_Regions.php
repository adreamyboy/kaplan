<?php
// created: 2014-05-06 13:00:13
$dictionary["GI_Regions"]["fields"]["gi_regions_gi_country_1"] = array (
  'name' => 'gi_regions_gi_country_1',
  'type' => 'link',
  'relationship' => 'gi_regions_gi_country_1',
  'source' => 'non-db',
  'module' => 'GI_Country',
  'bean_name' => 'GI_Country',
  'side' => 'right',
  'vname' => 'LBL_GI_REGIONS_GI_COUNTRY_1_FROM_GI_COUNTRY_TITLE',
);
