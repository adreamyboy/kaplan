<?php
 // created: 2015-01-27 21:51:01
$dictionary['GI_Line_Items']['fields']['moodle_user_id_c']['labelValue']='Moodle User ID';

 ?>