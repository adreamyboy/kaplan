<?php
 // created: 2014-05-06 15:34:14
$layout_defs["GI_Locations"]["subpanel_setup"]['gi_locations_gi_products_1'] = array (
  'order' => 100,
  'module' => 'GI_Products',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_LOCATIONS_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
  'get_subpanel_data' => 'gi_locations_gi_products_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
