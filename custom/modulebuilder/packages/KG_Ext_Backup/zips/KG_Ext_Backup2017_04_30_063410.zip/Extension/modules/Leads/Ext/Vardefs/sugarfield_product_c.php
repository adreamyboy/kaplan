<?php
 // created: 2016-05-10 02:11:23
$dictionary['Lead']['fields']['product_c']['labelValue']='Product (experimental - do not use)';

 ?>