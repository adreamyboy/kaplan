<?php
 // created: 2015-05-18 02:27:03
$dictionary['GI_Products']['fields']['quarter_c']['labelValue']='Quarter';

 ?>