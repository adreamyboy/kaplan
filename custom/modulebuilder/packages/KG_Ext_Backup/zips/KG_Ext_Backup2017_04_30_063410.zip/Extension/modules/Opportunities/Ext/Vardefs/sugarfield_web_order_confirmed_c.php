<?php
 // created: 2015-01-07 13:46:01
$dictionary['Opportunity']['fields']['web_order_confirmed_c']['labelValue']='Web Order Confirmed?';

 ?>