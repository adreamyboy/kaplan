<?php
 // created: 2014-08-30 11:43:13
$dictionary['GI_Products']['fields']['date_start_c']['options']='date_range_search_dom';
$dictionary['GI_Products']['fields']['date_start_c']['labelValue']='Date Start';
$dictionary['GI_Products']['fields']['date_start_c']['enable_range_search']='1';

 ?>