<?php
 // created: 2015-01-07 12:08:43
$dictionary['Lead']['fields']['payment_mode_c']['labelValue']='Payment Mode';

 ?>