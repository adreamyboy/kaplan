<?php
 // created: 2014-06-11 16:38:14
$dictionary['Opportunity']['fields']['reference_c']['labelValue']='Reference';
$dictionary['Opportunity']['fields']['reference_c']['autoinc_next']='1';
$dictionary['Opportunity']['fields']['reference_c']['auto_increment']=true;

 ?>