<?php
 // created: 2015-02-17 00:37:41
$dictionary['GI_Testimonials']['fields']['date_posted_c']['options']='date_range_search_dom';
$dictionary['GI_Testimonials']['fields']['date_posted_c']['labelValue']='Date Posted';
$dictionary['GI_Testimonials']['fields']['date_posted_c']['enable_range_search']='1';

 ?>