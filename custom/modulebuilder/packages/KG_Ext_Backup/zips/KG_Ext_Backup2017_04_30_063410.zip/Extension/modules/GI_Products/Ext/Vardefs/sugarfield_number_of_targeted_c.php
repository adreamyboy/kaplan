<?php
 // created: 2014-06-08 13:18:56
$dictionary['GI_Products']['fields']['number_of_targeted_c']['labelValue']='Number of Targeted';

 ?>