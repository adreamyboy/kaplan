<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Terms']['subpanel_setup']['gi_terms_gi_products_1']['override_subpanel_name'] = 'GI_Terms_subpanel_gi_terms_gi_products_1';
?>