<?php
 // created: 2014-06-13 12:02:41
 $dictionary['GI_Products']['fields']['discontinued']['massupdate']=true;

 ?>