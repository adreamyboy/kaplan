<?php
// created: 2014-11-11 03:11:15
$dictionary["GI_Products"]["fields"]["gi_discounts_gi_products_1"] = array (
  'name' => 'gi_discounts_gi_products_1',
  'type' => 'link',
  'relationship' => 'gi_discounts_gi_products_1',
  'source' => 'non-db',
  'module' => 'GI_Discounts',
  'bean_name' => 'GI_Discounts',
  'vname' => 'LBL_GI_DISCOUNTS_GI_PRODUCTS_1_FROM_GI_DISCOUNTS_TITLE',
);
