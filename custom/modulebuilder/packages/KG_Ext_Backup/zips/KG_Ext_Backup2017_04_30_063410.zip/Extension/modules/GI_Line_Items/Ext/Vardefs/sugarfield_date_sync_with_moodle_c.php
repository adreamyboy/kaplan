<?php
 // created: 2014-12-14 02:21:40
$dictionary['GI_Line_Items']['fields']['date_sync_with_moodle_c']['labelValue']='Date Sync with Moodle';

 ?>