<?php
 // created: 2014-05-31 02:49:56
$dictionary['GI_Line_Items']['fields']['reference_c']['labelValue']='Reference';
$dictionary['GI_Line_Items']['fields']['reference_c']['autoinc_next']='1';
$dictionary['GI_Line_Items']['fields']['reference_c']['auto_increment']=true;

 ?>