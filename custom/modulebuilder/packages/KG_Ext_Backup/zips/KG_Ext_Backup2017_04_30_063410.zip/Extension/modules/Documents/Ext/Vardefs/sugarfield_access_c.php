<?php
 // created: 2015-11-24 04:29:22
$dictionary['Document']['fields']['access_c']['labelValue']='Access';

 ?>