<?php
 // created: 2015-04-12 21:00:44
$dictionary['Opportunity']['fields']['send_invoice_via_email_c']['labelValue']='Send Invoice via Email';

 ?>