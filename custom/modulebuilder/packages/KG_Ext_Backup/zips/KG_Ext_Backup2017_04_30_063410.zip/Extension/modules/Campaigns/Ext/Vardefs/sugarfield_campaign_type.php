<?php
 // created: 2014-10-29 04:52:59
$dictionary['Campaign']['fields']['campaign_type']['required']=false;
$dictionary['Campaign']['fields']['campaign_type']['comments']='The type of campaign';
$dictionary['Campaign']['fields']['campaign_type']['merge_filter']='disabled';

 ?>