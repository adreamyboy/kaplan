<?php
 // created: 2015-10-20 10:25:10
$dictionary['Account']['fields']['employees']['comments']='Number of employees, varchar to accomodate for both number (100) or range (50-100)';
$dictionary['Account']['fields']['employees']['merge_filter']='disabled';

 ?>