<?php
 // created: 2014-05-08 10:35:33
$dictionary['GI_Products']['fields']['date_sync_with_moodle_c']['labelValue']='Date Sync with Moodle';

 ?>