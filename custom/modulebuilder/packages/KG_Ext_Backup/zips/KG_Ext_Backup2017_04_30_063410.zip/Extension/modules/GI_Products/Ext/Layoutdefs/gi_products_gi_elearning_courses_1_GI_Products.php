<?php
 // created: 2015-08-19 23:06:30
$layout_defs["GI_Products"]["subpanel_setup"]['gi_products_gi_elearning_courses_1'] = array (
  'order' => 100,
  'module' => 'GI_eLearning_Courses',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GI_PRODUCTS_GI_ELEARNING_COURSES_1_FROM_GI_ELEARNING_COURSES_TITLE',
  'get_subpanel_data' => 'gi_products_gi_elearning_courses_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
