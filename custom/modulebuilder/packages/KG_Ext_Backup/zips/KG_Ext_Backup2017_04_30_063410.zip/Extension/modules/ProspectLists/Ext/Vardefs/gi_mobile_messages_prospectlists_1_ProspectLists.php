<?php
// created: 2015-10-22 07:30:37
$dictionary["ProspectList"]["fields"]["gi_mobile_messages_prospectlists_1"] = array (
  'name' => 'gi_mobile_messages_prospectlists_1',
  'type' => 'link',
  'relationship' => 'gi_mobile_messages_prospectlists_1',
  'source' => 'non-db',
  'module' => 'GI_Mobile_Messages',
  'bean_name' => 'GI_Mobile_Messages',
  'vname' => 'LBL_GI_MOBILE_MESSAGES_PROSPECTLISTS_1_FROM_GI_MOBILE_MESSAGES_TITLE',
);
