<?php
// created: 2014-05-29 08:27:28
$dictionary["Account"]["fields"]["accounts_gi_credit_notes_1"] = array (
  'name' => 'accounts_gi_credit_notes_1',
  'type' => 'link',
  'relationship' => 'accounts_gi_credit_notes_1',
  'source' => 'non-db',
  'module' => 'GI_Credit_Notes',
  'bean_name' => 'GI_Credit_Notes',
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_GI_CREDIT_NOTES_1_FROM_GI_CREDIT_NOTES_TITLE',
);
