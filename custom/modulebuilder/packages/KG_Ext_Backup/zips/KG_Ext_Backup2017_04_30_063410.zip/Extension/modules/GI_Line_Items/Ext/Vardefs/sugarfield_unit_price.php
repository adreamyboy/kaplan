<?php
 // created: 2016-05-02 23:24:17
$dictionary['GI_Line_Items']['fields']['unit_price']['audited']=true;

 ?>