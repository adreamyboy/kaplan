<?php
 // created: 2014-06-13 12:03:35
$dictionary['GI_Products']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['GI_Products']['fields']['deleted']['merge_filter']='disabled';
$dictionary['GI_Products']['fields']['deleted']['reportable']=true;

 ?>