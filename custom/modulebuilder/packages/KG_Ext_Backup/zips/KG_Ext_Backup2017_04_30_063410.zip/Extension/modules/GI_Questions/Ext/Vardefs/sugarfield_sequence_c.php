<?php
 // created: 2015-02-07 21:10:46
$dictionary['GI_Questions']['fields']['sequence_c']['labelValue']='Sequence';

 ?>