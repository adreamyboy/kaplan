<?php
 // created: 2015-10-22 06:59:37
$dictionary['GI_Questions']['fields']['type_c']['labelValue']='Type';

 ?>