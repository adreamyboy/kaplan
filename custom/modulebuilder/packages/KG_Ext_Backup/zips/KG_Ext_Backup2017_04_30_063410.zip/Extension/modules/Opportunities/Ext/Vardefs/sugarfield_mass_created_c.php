<?php
 // created: 2017-03-13 02:24:52
$dictionary['Opportunity']['fields']['mass_created_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['mass_created_c']['labelValue']='Mass Created?';

 ?>