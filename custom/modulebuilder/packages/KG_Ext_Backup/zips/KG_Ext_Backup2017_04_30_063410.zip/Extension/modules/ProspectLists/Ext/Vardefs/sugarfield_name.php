<?php
 // created: 2015-07-12 04:32:57
$dictionary['ProspectList']['fields']['name']['len']='90';
$dictionary['ProspectList']['fields']['name']['merge_filter']='disabled';
$dictionary['ProspectList']['fields']['name']['unified_search']=false;
$dictionary['ProspectList']['fields']['name']['required']=true;
$dictionary['ProspectList']['fields']['name']['full_text_search']=array (
);

 ?>