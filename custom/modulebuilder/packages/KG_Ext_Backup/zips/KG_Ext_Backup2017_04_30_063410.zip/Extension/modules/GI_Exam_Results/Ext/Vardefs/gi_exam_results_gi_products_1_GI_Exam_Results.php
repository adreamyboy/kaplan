<?php
// created: 2015-07-08 05:44:07
$dictionary["GI_Exam_Results"]["fields"]["gi_exam_results_gi_products_1"] = array (
  'name' => 'gi_exam_results_gi_products_1',
  'type' => 'link',
  'relationship' => 'gi_exam_results_gi_products_1',
  'source' => 'non-db',
  'module' => 'GI_Products',
  'bean_name' => 'GI_Products',
  'side' => 'right',
  'vname' => 'LBL_GI_EXAM_RESULTS_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
);
