<?php
//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['accounts_gi_credit_notes_1']['override_subpanel_name'] = 'Account_subpanel_accounts_gi_credit_notes_1';
?>