<?php
// created: 2014-05-08 10:46:41
$dictionary["GI_Products"]["fields"]["gi_products_meetings_1"] = array (
  'name' => 'gi_products_meetings_1',
  'type' => 'link',
  'relationship' => 'gi_products_meetings_1',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'side' => 'right',
  'vname' => 'LBL_GI_PRODUCTS_MEETINGS_1_FROM_MEETINGS_TITLE',
);
