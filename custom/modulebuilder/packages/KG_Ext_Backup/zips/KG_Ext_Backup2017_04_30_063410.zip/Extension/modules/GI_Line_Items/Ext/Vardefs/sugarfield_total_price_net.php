<?php
 // created: 2014-05-29 04:30:36
$dictionary['GI_Line_Items']['fields']['total_price_net']['required']=false;

 ?>