<?php
 // created: 2015-02-17 00:06:02
$dictionary['GI_Testimonials']['fields']['video_url_c']['labelValue']='Video URL';

 ?>