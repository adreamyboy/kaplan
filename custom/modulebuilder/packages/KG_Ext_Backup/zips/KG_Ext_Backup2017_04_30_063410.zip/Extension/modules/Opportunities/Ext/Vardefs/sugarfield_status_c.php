<?php
 // created: 2014-06-21 13:58:00
$dictionary['Opportunity']['fields']['status_c']['labelValue']='Status';

 ?>