<?php
 // created: 2015-09-10 05:22:54
$dictionary['GI_Line_Items']['fields']['date_delivered_c']['options']='date_range_search_dom';
$dictionary['GI_Line_Items']['fields']['date_delivered_c']['labelValue']='Date Delivered';
$dictionary['GI_Line_Items']['fields']['date_delivered_c']['enable_range_search']='1';

 ?>