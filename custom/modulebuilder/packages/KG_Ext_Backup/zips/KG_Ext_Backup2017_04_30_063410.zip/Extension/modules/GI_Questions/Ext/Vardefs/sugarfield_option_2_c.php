<?php
 // created: 2015-02-07 20:14:21
$dictionary['GI_Questions']['fields']['option_2_c']['labelValue']='Option 2';

 ?>