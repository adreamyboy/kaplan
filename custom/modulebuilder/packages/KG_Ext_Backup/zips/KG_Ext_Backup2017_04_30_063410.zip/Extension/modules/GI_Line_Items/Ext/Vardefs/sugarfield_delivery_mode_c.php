<?php
 // created: 2015-09-13 06:11:44
$dictionary['GI_Line_Items']['fields']['delivery_mode_c']['labelValue']='Preferred Delivery Mode';

 ?>