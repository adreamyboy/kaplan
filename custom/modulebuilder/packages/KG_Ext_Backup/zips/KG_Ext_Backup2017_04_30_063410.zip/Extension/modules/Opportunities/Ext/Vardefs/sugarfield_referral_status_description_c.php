<?php
 // created: 2016-02-07 12:05:33
$dictionary['Opportunity']['fields']['referral_status_description_c']['labelValue']='Referral Status Description';

 ?>