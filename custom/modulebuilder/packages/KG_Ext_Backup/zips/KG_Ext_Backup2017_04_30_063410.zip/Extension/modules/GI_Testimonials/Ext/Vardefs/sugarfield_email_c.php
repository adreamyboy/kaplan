<?php
 // created: 2015-02-16 21:54:18
$dictionary['GI_Testimonials']['fields']['email_c']['labelValue']='Email';

 ?>