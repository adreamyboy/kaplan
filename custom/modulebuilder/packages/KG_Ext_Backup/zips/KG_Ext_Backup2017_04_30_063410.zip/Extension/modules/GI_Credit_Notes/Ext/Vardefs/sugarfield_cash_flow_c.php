<?php
 // created: 2014-09-03 02:29:31
$dictionary['GI_Credit_Notes']['fields']['cash_flow_c']['labelValue']='Cash Flow';

 ?>