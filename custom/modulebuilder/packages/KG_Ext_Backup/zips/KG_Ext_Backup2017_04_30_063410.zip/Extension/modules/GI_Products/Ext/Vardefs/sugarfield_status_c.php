<?php
 // created: 2014-06-21 19:55:46
$dictionary['GI_Products']['fields']['status_c']['labelValue']='Status';

 ?>