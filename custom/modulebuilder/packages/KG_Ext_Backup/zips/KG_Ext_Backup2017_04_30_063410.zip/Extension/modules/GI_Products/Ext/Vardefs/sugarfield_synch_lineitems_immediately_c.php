<?php
 // created: 2014-12-09 12:59:34
$dictionary['GI_Products']['fields']['synch_lineitems_immediately_c']['labelValue']='Synch LineItems Immediately?';

 ?>