<?php
 // created: 2015-02-16 21:55:45
$dictionary['GI_Testimonials']['fields']['company_c']['labelValue']='Company';

 ?>