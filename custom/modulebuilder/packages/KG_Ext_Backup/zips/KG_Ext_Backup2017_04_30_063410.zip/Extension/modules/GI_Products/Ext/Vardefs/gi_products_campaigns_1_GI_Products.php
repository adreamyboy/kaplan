<?php
// created: 2014-06-17 06:48:24
$dictionary["GI_Products"]["fields"]["gi_products_campaigns_1"] = array (
  'name' => 'gi_products_campaigns_1',
  'type' => 'link',
  'relationship' => 'gi_products_campaigns_1',
  'source' => 'non-db',
  'module' => 'Campaigns',
  'bean_name' => 'Campaign',
  'side' => 'right',
  'vname' => 'LBL_GI_PRODUCTS_CAMPAIGNS_1_FROM_CAMPAIGNS_TITLE',
);
