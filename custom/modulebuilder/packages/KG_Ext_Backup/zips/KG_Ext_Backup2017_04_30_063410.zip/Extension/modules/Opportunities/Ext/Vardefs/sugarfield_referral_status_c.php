<?php
 // created: 2016-02-07 12:04:48
$dictionary['Opportunity']['fields']['referral_status_c']['labelValue']='Referral Status';

 ?>