<?php
 // created: 2014-10-12 04:18:21
$dictionary['GI_SMS_Messages']['fields']['date_scheduled_c']['options']='date_range_search_dom';
$dictionary['GI_SMS_Messages']['fields']['date_scheduled_c']['labelValue']='Date/Time Scheduled';
$dictionary['GI_SMS_Messages']['fields']['date_scheduled_c']['enable_range_search']='1';

 ?>