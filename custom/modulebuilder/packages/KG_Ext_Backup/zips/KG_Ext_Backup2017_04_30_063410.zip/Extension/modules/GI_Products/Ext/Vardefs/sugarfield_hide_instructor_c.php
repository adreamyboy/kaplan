<?php
 // created: 2015-06-10 21:16:53
$dictionary['GI_Products']['fields']['hide_instructor_c']['labelValue']='Hide Instructor in PDF';

 ?>