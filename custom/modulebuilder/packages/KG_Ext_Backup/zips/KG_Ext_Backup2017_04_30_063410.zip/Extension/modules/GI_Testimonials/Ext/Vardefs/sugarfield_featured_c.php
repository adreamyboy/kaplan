<?php
 // created: 2015-02-18 12:47:39
$dictionary['GI_Testimonials']['fields']['featured_c']['labelValue']='Featured';

 ?>