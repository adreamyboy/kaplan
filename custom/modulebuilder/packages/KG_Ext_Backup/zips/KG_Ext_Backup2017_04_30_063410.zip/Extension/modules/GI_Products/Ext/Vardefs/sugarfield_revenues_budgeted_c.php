<?php
 // created: 2014-07-03 00:50:33
$dictionary['GI_Products']['fields']['revenues_budgeted_c']['labelValue']='Revenues Budgeted';

 ?>