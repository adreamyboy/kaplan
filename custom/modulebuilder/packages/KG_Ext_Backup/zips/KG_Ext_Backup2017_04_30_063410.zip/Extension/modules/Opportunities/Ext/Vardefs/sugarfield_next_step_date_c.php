<?php
 // created: 2015-10-25 04:25:14
$dictionary['Opportunity']['fields']['next_step_date_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['next_step_date_c']['labelValue']='Next Step Date';
$dictionary['Opportunity']['fields']['next_step_date_c']['enable_range_search']='1';

 ?>