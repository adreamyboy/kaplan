<?php
 // created: 2014-09-28 10:30:58
$dictionary['GI_Line_Items']['fields']['create_followup_task_c']['labelValue']='Create a New Follow-up Task';
$dictionary['GI_Line_Items']['fields']['create_followup_task_c']['massupdate']=true;

 ?>