<?php
 // created: 2014-08-30 11:42:44
$dictionary['GI_Products']['fields']['price']['audited']=true;

 ?>