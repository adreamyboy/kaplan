<?php
 // created: 2014-09-03 02:28:31
$dictionary['Opportunity']['fields']['cash_flow_c']['labelValue']='Cash Flow';

 ?>