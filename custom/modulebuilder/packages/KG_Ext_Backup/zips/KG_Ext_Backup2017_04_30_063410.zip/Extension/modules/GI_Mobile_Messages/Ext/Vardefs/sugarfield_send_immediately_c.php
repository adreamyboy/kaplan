<?php
 // created: 2015-10-22 07:28:38
$dictionary['GI_Mobile_Messages']['fields']['send_immediately_c']['labelValue']='Send Immediately';

 ?>