<?php
//auto-generated file DO NOT EDIT
$layout_defs['GI_Credit_Notes']['subpanel_setup']['gi_credit_notes_gi_payments_1']['override_subpanel_name'] = 'GI_Credit_Notes_subpanel_gi_credit_notes_gi_payments_1';
?>