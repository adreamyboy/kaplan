<?php
 // created: 2014-07-16 13:23:42
$dictionary['GI_Products']['fields']['days_c']['labelValue']='Days';

 ?>