<?php
 // created: 2015-08-26 23:48:57
$dictionary['Account']['fields']['tier_c']['labelValue']='Tier';

 ?>