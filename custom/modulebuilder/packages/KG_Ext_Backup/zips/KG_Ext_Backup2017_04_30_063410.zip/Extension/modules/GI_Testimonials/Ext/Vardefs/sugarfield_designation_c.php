<?php
 // created: 2015-02-17 00:04:58
$dictionary['GI_Testimonials']['fields']['designation_c']['labelValue']='Designation';

 ?>