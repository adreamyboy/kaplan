<?php
 // created: 2014-06-18 15:44:30
$dictionary['Opportunity']['fields']['date_closed']['required']=false;
$dictionary['Opportunity']['fields']['date_closed']['comments']='Actual date the opportunity close';
$dictionary['Opportunity']['fields']['date_closed']['importable']='true';
$dictionary['Opportunity']['fields']['date_closed']['merge_filter']='disabled';

 ?>