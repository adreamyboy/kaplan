<?php
 // created: 2014-08-30 11:44:27
$dictionary['GI_Products']['fields']['batch_c']['labelValue']='Batch';

 ?>