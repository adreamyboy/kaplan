<?php
// created: 2014-05-08 09:52:12
$dictionary["GI_Products"]["fields"]["gi_products_gi_line_items_1"] = array (
  'name' => 'gi_products_gi_line_items_1',
  'type' => 'link',
  'relationship' => 'gi_products_gi_line_items_1',
  'source' => 'non-db',
  'module' => 'GI_Line_Items',
  'bean_name' => 'GI_Line_Items',
  'side' => 'right',
  'vname' => 'LBL_GI_PRODUCTS_GI_LINE_ITEMS_1_FROM_GI_LINE_ITEMS_TITLE',
);
