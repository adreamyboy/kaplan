<?php
 // created: 2015-07-12 05:55:43
$dictionary['ProspectList']['fields']['system_protected_c']['labelValue']='System Protected';

 ?>