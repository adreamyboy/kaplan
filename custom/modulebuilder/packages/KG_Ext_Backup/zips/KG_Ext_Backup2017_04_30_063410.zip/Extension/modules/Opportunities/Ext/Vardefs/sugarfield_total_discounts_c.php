<?php
 // created: 2014-05-08 09:28:39
$dictionary['Opportunity']['fields']['total_discounts_c']['labelValue']='Total Discounts';

 ?>