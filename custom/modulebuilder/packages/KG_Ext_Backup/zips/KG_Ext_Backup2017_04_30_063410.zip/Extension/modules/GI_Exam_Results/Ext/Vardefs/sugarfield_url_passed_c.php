<?php
 // created: 2015-07-27 05:26:01
$dictionary['GI_Exam_Results']['fields']['url_passed_c']['labelValue']='URL Passed';

 ?>