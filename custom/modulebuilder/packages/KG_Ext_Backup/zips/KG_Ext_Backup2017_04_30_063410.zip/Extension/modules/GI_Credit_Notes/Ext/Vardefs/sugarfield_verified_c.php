<?php
 // created: 2014-06-29 07:49:23
$dictionary['GI_Credit_Notes']['fields']['verified_c']['labelValue']='Verified';

 ?>