<?php
 // created: 2016-11-24 06:16:02
$dictionary['Lead']['fields']['send_coupon_via_email_c']['labelValue']='Send Coupon Via Email';

 ?>