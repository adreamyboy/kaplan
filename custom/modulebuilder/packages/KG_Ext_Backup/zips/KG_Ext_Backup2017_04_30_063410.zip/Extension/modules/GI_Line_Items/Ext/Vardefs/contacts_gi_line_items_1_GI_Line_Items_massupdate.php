<?php
// created by: Tawfeeq Jaafar
/*
$dictionary["GI_Line_Items"]["fields"]["contacts_gi_line_items_1"] = array (
  'massupdate' => 0,
);
$dictionary["GI_Line_Items"]["fields"]["contacts_gi_line_items_1_name"] = array (
  'massupdate' => 0,
);
$dictionary["GI_Line_Items"]["fields"]["contacts_gi_line_items_1contacts_ida"] = array (
  'massupdate' => 0,
);
*/
