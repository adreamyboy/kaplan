<?php
 // created: 2014-08-30 11:42:57
$dictionary['GI_Products']['fields']['type']['audited']=true;

 ?>