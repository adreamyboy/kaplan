<?php
 // created: 2015-02-07 20:14:40
$dictionary['GI_Questions']['fields']['option_3_c']['labelValue']='Option 3';

 ?>