<?php
 // created: 2015-01-10 00:41:55
$dictionary['GI_Terms']['fields']['year_c']['labelValue']='Year';

 ?>