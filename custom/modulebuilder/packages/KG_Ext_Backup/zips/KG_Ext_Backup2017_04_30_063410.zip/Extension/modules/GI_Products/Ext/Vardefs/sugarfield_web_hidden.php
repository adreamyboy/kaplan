<?php
 // created: 2014-11-11 17:23:24
$dictionary['GI_Products']['fields']['web_hidden']['audited']=true;
$dictionary['GI_Products']['fields']['web_hidden']['default']='1';
$dictionary['GI_Products']['fields']['web_hidden']['massupdate']=true;

 ?>