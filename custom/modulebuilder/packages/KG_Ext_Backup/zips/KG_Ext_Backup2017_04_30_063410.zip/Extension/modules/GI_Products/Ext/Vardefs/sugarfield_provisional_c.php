<?php
 // created: 2014-05-08 10:33:07
$dictionary['GI_Products']['fields']['provisional_c']['labelValue']='Provisional';

 ?>