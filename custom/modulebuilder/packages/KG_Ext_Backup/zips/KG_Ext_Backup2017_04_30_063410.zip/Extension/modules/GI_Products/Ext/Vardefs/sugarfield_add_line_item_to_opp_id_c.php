<?php
 // created: 2015-10-21 10:08:57
$dictionary['GI_Products']['fields']['add_line_item_to_opp_id_c']['labelValue']='Automatically add a new Line Item to Opportunity ID';

 ?>