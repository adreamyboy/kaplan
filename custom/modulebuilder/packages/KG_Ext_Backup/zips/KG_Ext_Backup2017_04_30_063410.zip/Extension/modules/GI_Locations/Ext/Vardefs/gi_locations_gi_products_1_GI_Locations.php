<?php
// created: 2014-05-06 15:34:14
$dictionary["GI_Locations"]["fields"]["gi_locations_gi_products_1"] = array (
  'name' => 'gi_locations_gi_products_1',
  'type' => 'link',
  'relationship' => 'gi_locations_gi_products_1',
  'source' => 'non-db',
  'module' => 'GI_Products',
  'bean_name' => 'GI_Products',
  'side' => 'right',
  'vname' => 'LBL_GI_LOCATIONS_GI_PRODUCTS_1_FROM_GI_PRODUCTS_TITLE',
);
