<?php
 // created: 2015-02-07 21:11:31
$dictionary['GI_Questions']['fields']['discontinued_c']['labelValue']='Discontinued';

 ?>