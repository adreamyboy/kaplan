<?php
 // created: 2014-08-05 00:25:38
$dictionary['GI_Products']['fields']['date_end_c']['options']='date_range_search_dom';
$dictionary['GI_Products']['fields']['date_end_c']['labelValue']='Date End';
$dictionary['GI_Products']['fields']['date_end_c']['enable_range_search']='1';

 ?>