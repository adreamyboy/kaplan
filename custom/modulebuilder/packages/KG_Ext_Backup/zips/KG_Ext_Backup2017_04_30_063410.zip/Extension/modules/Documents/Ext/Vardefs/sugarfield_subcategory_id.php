<?php
 // created: 2015-11-24 06:36:23
$dictionary['Document']['fields']['subcategory_id']['merge_filter']='disabled';

 ?>