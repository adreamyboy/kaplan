<?php
 // created: 2015-01-27 22:26:10
$dictionary['Lead']['fields']['send_email_verification_link_c']['labelValue']='Send Email Verification Link';

 ?>