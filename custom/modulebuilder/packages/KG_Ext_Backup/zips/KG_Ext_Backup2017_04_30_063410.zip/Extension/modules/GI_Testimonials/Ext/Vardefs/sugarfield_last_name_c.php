<?php
 // created: 2015-02-16 21:55:16
$dictionary['GI_Testimonials']['fields']['last_name_c']['labelValue']='Last Name';

 ?>