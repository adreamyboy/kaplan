<?php
 // created: 2015-03-15 02:00:52
$dictionary['Opportunity']['fields']['sales_stage']['default']='Open';
$dictionary['Opportunity']['fields']['sales_stage']['len']=100;
$dictionary['Opportunity']['fields']['sales_stage']['comments']='Indication of progression towards closure';
$dictionary['Opportunity']['fields']['sales_stage']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['sales_stage']['required']=true;

 ?>