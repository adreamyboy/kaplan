<?php
 // created: 2014-06-01 18:37:47
$dictionary['GI_Credit_Notes']['fields']['amount_unallocated_c']['labelValue']='Amount Unallocated';

 ?>