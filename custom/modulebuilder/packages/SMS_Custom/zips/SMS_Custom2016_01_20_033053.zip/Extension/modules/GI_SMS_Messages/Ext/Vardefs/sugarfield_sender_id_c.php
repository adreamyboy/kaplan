<?php
 // created: 2015-05-07 00:20:43
$dictionary['GI_SMS_Messages']['fields']['sender_id_c']['labelValue']='Sender ID';

 ?>