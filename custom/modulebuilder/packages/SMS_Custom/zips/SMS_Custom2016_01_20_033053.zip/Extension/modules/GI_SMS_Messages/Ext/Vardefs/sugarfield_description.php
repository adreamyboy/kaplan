<?php
 // created: 2014-10-12 16:11:58
$dictionary['GI_SMS_Messages']['fields']['description']['comments']='Full text of the note';
$dictionary['GI_SMS_Messages']['fields']['description']['merge_filter']='disabled';

 ?>