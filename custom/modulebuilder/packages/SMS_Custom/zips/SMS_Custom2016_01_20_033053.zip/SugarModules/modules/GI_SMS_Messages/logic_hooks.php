<?php
$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
$hook_array['after_save'][] = Array(
    0,
    'If opportunity is deleted, delete the line item completely from database',
    'custom/modules/GI_SMS_Messages/logic_hooks/logic_hooks_GI_SMS_Messages.php',
    'logic_hooks_GI_SMS_Messages',
    'after_save_method'
);

?>