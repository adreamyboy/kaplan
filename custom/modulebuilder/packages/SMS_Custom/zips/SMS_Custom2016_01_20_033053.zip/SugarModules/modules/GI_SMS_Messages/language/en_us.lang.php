<?php 
 // created: 2016-01-20 03:30:52
$mod_strings['LBL_SENDER_ID'] = 'Sender ID';
$mod_strings['LBL_SEND_IMMEDIATELY'] = 'Send Immediately';
$mod_strings['LBL_DATE_SCHEDULED'] = 'Date/Time Scheduled';
$mod_strings['LNK_NEW_RECORD'] = 'Create SMS Messages';
$mod_strings['LNK_LIST'] = 'View SMS Messages';
$mod_strings['LNK_IMPORT_GI_SMS_MESSAGES'] = 'Import SMS Messages';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'SMS Message List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search SMS Message';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My SMS Message';
$mod_strings['LBL_DESCRIPTION'] = 'Message';

?>
